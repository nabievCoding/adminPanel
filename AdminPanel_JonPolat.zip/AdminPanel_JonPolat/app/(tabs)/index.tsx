import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Card, ProgressBar, Button } from 'react-native-paper';
import Animated, { FadeInUp, FadeInLeft } from 'react-native-reanimated';
import { useGame } from '../../hooks/useGame';

const AnimatedCard = Animated.createAnimatedComponent(Card);

export default function HomeScreen() {
  const { user, achievements, lessons } = useGame();

  const completedLessons = lessons.filter(lesson => lesson.completed).length;
  const totalLessons = lessons.length;
  const progressPercentage = (completedLessons / totalLessons) * 100;

  const unlockedAchievements = achievements.filter(achievement => achievement.unlocked);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Hello, {user.name}! 👋</Text>
            <Text style={styles.subtitle}>Ready to build some robots?</Text>
          </View>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>{user.avatar}</Text>
          </View>
        </View>

        {/* Stats Cards */}
        <View style={styles.statsContainer}>
          <AnimatedCard entering={FadeInUp.delay(100)} style={styles.statCard}>
            <Card.Content style={styles.statContent}>
              <MaterialIcons name="monetization-on" size={24} color="#FF9800" />
              <Text style={styles.statNumber}>{user.coins}</Text>
              <Text style={styles.statLabel}>Coins</Text>
            </Card.Content>
          </AnimatedCard>

          <AnimatedCard entering={FadeInUp.delay(200)} style={styles.statCard}>
            <Card.Content style={styles.statContent}>
              <MaterialIcons name="local-fire-department" size={24} color="#FF5722" />
              <Text style={styles.statNumber}>{user.streak}</Text>
              <Text style={styles.statLabel}>Day Streak</Text>
            </Card.Content>
          </AnimatedCard>

          <AnimatedCard entering={FadeInUp.delay(300)} style={styles.statCard}>
            <Card.Content style={styles.statContent}>
              <MaterialIcons name="stars" size={24} color="#9C27B0" />
              <Text style={styles.statNumber}>{user.level}</Text>
              <Text style={styles.statLabel}>Level</Text>
            </Card.Content>
          </AnimatedCard>
        </View>

        {/* Progress Section */}
        <AnimatedCard entering={FadeInLeft.delay(400)} style={styles.card}>
          <Card.Content>
            <View style={styles.cardHeader}>
              <MaterialIcons name="trending-up" size={24} color="#00BCD4" />
              <Text style={styles.cardTitle}>Learning Progress</Text>
            </View>
            <View style={styles.progressContainer}>
              <Text style={styles.progressText}>
                {completedLessons} of {totalLessons} lessons completed
              </Text>
              <ProgressBar 
                progress={progressPercentage / 100} 
                color="#00BCD4"
                style={styles.progressBar}
              />
              <Text style={styles.progressPercentage}>{Math.round(progressPercentage)}%</Text>
            </View>
          </Card.Content>
        </AnimatedCard>

        {/* Daily Goal */}
        <AnimatedCard entering={FadeInLeft.delay(500)} style={styles.card}>
          <Card.Content>
            <View style={styles.cardHeader}>
              <MaterialIcons name="today" size={24} color="#4CAF50" />
              <Text style={styles.cardTitle}>Daily Goal</Text>
            </View>
            <Text style={styles.goalText}>Complete 1 lesson or quiz today</Text>
            <Button 
              mode="contained" 
              onPress={() => {}} 
              style={styles.goalButton}
              buttonColor="#4CAF50"
            >
              Start Learning
            </Button>
          </Card.Content>
        </AnimatedCard>

        {/* Recent Achievements */}
        <AnimatedCard entering={FadeInLeft.delay(600)} style={styles.card}>
          <Card.Content>
            <View style={styles.cardHeader}>
              <MaterialIcons name="emoji-events" size={24} color="#FFD700" />
              <Text style={styles.cardTitle}>Recent Achievements</Text>
            </View>
            {unlockedAchievements.slice(-2).map((achievement, index) => (
              <View key={achievement.id} style={styles.achievementItem}>
                <MaterialIcons name={achievement.icon as any} size={20} color="#FFD700" />
                <View style={styles.achievementText}>
                  <Text style={styles.achievementTitle}>{achievement.title}</Text>
                  <Text style={styles.achievementDesc}>{achievement.description}</Text>
                </View>
                <Text style={styles.achievementReward}>+{achievement.coinReward}</Text>
              </View>
            ))}
          </Card.Content>
        </AnimatedCard>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingTop: 10,
  },
  greeting: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginTop: 4,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#E3F2FD',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    fontSize: 24,
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    elevation: 2,
  },
  statContent: {
    alignItems: 'center',
    padding: 12,
  },
  statNumber: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginTop: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  card: {
    margin: 20,
    marginTop: 16,
    backgroundColor: '#FFFFFF',
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginLeft: 8,
  },
  progressContainer: {
    gap: 8,
  },
  progressText: {
    fontSize: 14,
    color: '#666',
  },
  progressBar: {
    height: 8,
    borderRadius: 4,
    backgroundColor: '#E3F2FD',
  },
  progressPercentage: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#00BCD4',
    textAlign: 'center',
  },
  goalText: {
    fontSize: 16,
    color: '#666',
    marginBottom: 16,
  },
  goalButton: {
    borderRadius: 8,
  },
  achievementItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  achievementText: {
    flex: 1,
    marginLeft: 12,
  },
  achievementTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  achievementDesc: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  achievementReward: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#FF9800',
  },
});