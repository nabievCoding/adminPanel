import React from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Card } from 'react-native-paper';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { useGame } from '../../hooks/useGame';
import { LeaderboardEntry } from '../../services/types';

const AnimatedCard = Animated.createAnimatedComponent(Card);

export default function LeaderboardScreen() {
  const { leaderboard, user } = useGame();

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return '🥇';
      case 2: return '🥈';
      case 3: return '🥉';
      default: return `#${rank}`;
    }
  };

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1: return '#FFD700';
      case 2: return '#C0C0C0';
      case 3: return '#CD7F32';
      default: return '#666';
    }
  };

  const renderLeaderboardItem = ({ item, index }: { item: LeaderboardEntry; index: number }) => {
    const isCurrentUser = item.id === user.id;
    
    return (
      <AnimatedCard
        entering={FadeInDown.delay(index * 50)}
        style={[
          styles.leaderboardCard,
          isCurrentUser && styles.currentUserCard
        ]}
      >
        <Card.Content style={styles.cardContent}>
          <View style={styles.rankContainer}>
            <Text style={[
              styles.rankText,
              { color: getRankColor(item.rank) }
            ]}>
              {getRankIcon(item.rank)}
            </Text>
          </View>

          <View style={styles.avatarContainer}>
            <Text style={styles.avatar}>{item.avatar}</Text>
          </View>

          <View style={styles.userInfo}>
            <Text style={[
              styles.userName,
              isCurrentUser && styles.currentUserText
            ]}>
              {item.name}
              {isCurrentUser && ' (You)'}
            </Text>
            <View style={styles.statsRow}>
              <View style={styles.stat}>
                <MaterialIcons name="stars" size={14} color="#9C27B0" />
                <Text style={styles.statText}>{item.points} XP</Text>
              </View>
              <View style={styles.stat}>
                <MaterialIcons name="local-fire-department" size={14} color="#FF5722" />
                <Text style={styles.statText}>{item.streak} days</Text>
              </View>
            </View>
          </View>

          {item.rank <= 3 && (
            <MaterialIcons 
              name="emoji-events" 
              size={24} 
              color={getRankColor(item.rank)} 
            />
          )}
        </Card.Content>
      </AnimatedCard>
    );
  };

  const topThree = leaderboard.slice(0, 3);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Leaderboard</Text>
        <Text style={styles.subtitle}>Compete with fellow robot builders!</Text>
      </View>

      {/* Top 3 Podium */}
      <View style={styles.podiumContainer}>
        <Text style={styles.podiumTitle}>🏆 Top Performers</Text>
        <View style={styles.podium}>
          {/* Second Place */}
          {topThree[1] && (
            <AnimatedCard 
              entering={FadeInDown.delay(100)}
              style={[styles.podiumCard, styles.secondPlace]}
            >
              <Card.Content style={styles.podiumContent}>
                <Text style={styles.podiumAvatar}>{topThree[1].avatar}</Text>
                <Text style={styles.podiumRank}>🥈</Text>
                <Text style={styles.podiumName}>{topThree[1].name}</Text>
                <Text style={styles.podiumPoints}>{topThree[1].points} XP</Text>
              </Card.Content>
            </AnimatedCard>
          )}

          {/* First Place */}
          {topThree[0] && (
            <AnimatedCard 
              entering={FadeInDown.delay(200)}
              style={[styles.podiumCard, styles.firstPlace]}
            >
              <Card.Content style={styles.podiumContent}>
                <Text style={styles.podiumAvatar}>{topThree[0].avatar}</Text>
                <Text style={styles.podiumRank}>🥇</Text>
                <Text style={styles.podiumName}>{topThree[0].name}</Text>
                <Text style={styles.podiumPoints}>{topThree[0].points} XP</Text>
              </Card.Content>
            </AnimatedCard>
          )}

          {/* Third Place */}
          {topThree[2] && (
            <AnimatedCard 
              entering={FadeInDown.delay(300)}
              style={[styles.podiumCard, styles.thirdPlace]}
            >
              <Card.Content style={styles.podiumContent}>
                <Text style={styles.podiumAvatar}>{topThree[2].avatar}</Text>
                <Text style={styles.podiumRank}>🥉</Text>
                <Text style={styles.podiumName}>{topThree[2].name}</Text>
                <Text style={styles.podiumPoints}>{topThree[2].points} XP</Text>
              </Card.Content>
            </AnimatedCard>
          )}
        </View>
      </View>

      {/* Full Leaderboard */}
      <View style={styles.listHeader}>
        <Text style={styles.listTitle}>All Rankings</Text>
      </View>

      <FlatList
        data={leaderboard}
        renderItem={renderLeaderboardItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA',
  },
  header: {
    padding: 20,
    paddingTop: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginTop: 4,
  },
  podiumContainer: {
    padding: 20,
    paddingTop: 0,
  },
  podiumTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1A1A1A',
    textAlign: 'center',
    marginBottom: 16,
  },
  podium: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'flex-end',
    gap: 8,
  },
  podiumCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    elevation: 3,
  },
  firstPlace: {
    marginBottom: 0,
  },
  secondPlace: {
    marginBottom: 20,
  },
  thirdPlace: {
    marginBottom: 40,
  },
  podiumContent: {
    alignItems: 'center',
    padding: 12,
  },
  podiumAvatar: {
    fontSize: 32,
    marginBottom: 8,
  },
  podiumRank: {
    fontSize: 24,
    marginBottom: 4,
  },
  podiumName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#1A1A1A',
    textAlign: 'center',
    marginBottom: 4,
  },
  podiumPoints: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
  listHeader: {
    paddingHorizontal: 20,
    paddingBottom: 8,
  },
  listTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  listContainer: {
    padding: 20,
    paddingTop: 0,
  },
  leaderboardCard: {
    marginBottom: 12,
    backgroundColor: '#FFFFFF',
    elevation: 2,
  },
  currentUserCard: {
    borderColor: '#00BCD4',
    borderWidth: 2,
  },
  cardContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  rankContainer: {
    width: 40,
    alignItems: 'center',
  },
  rankText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  avatarContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#E3F2FD',
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 12,
  },
  avatar: {
    fontSize: 20,
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginBottom: 4,
  },
  currentUserText: {
    color: '#00BCD4',
  },
  statsRow: {
    flexDirection: 'row',
    gap: 16,
  },
  stat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statText: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
});