import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Card, ProgressBar, Chip } from 'react-native-paper';
import Animated, { FadeInRight } from 'react-native-reanimated';
import { useGame } from '../../hooks/useGame';
import { Lesson } from '../../services/types';

const AnimatedCard = Animated.createAnimatedComponent(Card);

export default function LessonsScreen() {
  const { lessons, completeLesson } = useGame();

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return '#4CAF50';
      case 'Intermediate': return '#FF9800';
      case 'Advanced': return '#F44336';
      default: return '#666';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'basics': return 'lightbulb';
      case 'sensors': return 'sensors';
      case 'motors': return 'settings';
      case 'programming': return 'code';
      case 'projects': return 'build';
      default: return 'school';
    }
  };

  const handleLessonPress = (lesson: Lesson) => {
    if (!lesson.locked && !lesson.completed) {
      completeLesson(lesson.id);
    }
  };

  const renderLesson = ({ item, index }: { item: Lesson; index: number }) => (
    <AnimatedCard 
      entering={FadeInRight.delay(index * 100)}
      style={[
        styles.lessonCard,
        item.locked && styles.lockedCard
      ]}
    >
      <TouchableOpacity
        onPress={() => handleLessonPress(item)}
        disabled={item.locked}
        style={styles.lessonContent}
      >
        <View style={styles.lessonHeader}>
          <View style={styles.iconContainer}>
            <MaterialIcons 
              name={getCategoryIcon(item.category) as any} 
              size={24} 
              color={item.locked ? '#CCC' : '#00BCD4'} 
            />
          </View>
          <View style={styles.lessonInfo}>
            <Text style={[
              styles.lessonTitle,
              item.locked && styles.lockedText
            ]}>
              {item.title}
            </Text>
            <Text style={[
              styles.lessonDescription,
              item.locked && styles.lockedText
            ]}>
              {item.description}
            </Text>
          </View>
          {item.completed && (
            <MaterialIcons name="check-circle" size={24} color="#4CAF50" />
          )}
          {item.locked && (
            <MaterialIcons name="lock" size={24} color="#CCC" />
          )}
        </View>

        <View style={styles.lessonMeta}>
          <Chip 
            mode="outlined" 
            textStyle={{ 
              color: getDifficultyColor(item.difficulty),
              fontSize: 12 
            }}
            style={[
              styles.difficultyChip,
              { borderColor: getDifficultyColor(item.difficulty) }
            ]}
          >
            {item.difficulty}
          </Chip>
          <View style={styles.rewards}>
            <View style={styles.reward}>
              <MaterialIcons name="stars" size={16} color="#9C27B0" />
              <Text style={styles.rewardText}>{item.xpReward} XP</Text>
            </View>
            <View style={styles.reward}>
              <MaterialIcons name="monetization-on" size={16} color="#FF9800" />
              <Text style={styles.rewardText}>{item.coinReward}</Text>
            </View>
          </View>
        </View>

        {!item.locked && item.progress > 0 && (
          <View style={styles.progressContainer}>
            <ProgressBar 
              progress={item.progress / 100} 
              color={item.completed ? '#4CAF50' : '#00BCD4'}
              style={styles.progressBar}
            />
            <Text style={styles.progressText}>{item.progress}%</Text>
          </View>
        )}
      </TouchableOpacity>
    </AnimatedCard>
  );

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Robotics Lessons</Text>
        <Text style={styles.subtitle}>Master the fundamentals of robotics</Text>
      </View>

      <FlatList
        data={lessons}
        renderItem={renderLesson}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA',
  },
  header: {
    padding: 20,
    paddingTop: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginTop: 4,
  },
  listContainer: {
    padding: 20,
    paddingTop: 0,
  },
  lessonCard: {
    marginBottom: 16,
    backgroundColor: '#FFFFFF',
    elevation: 2,
  },
  lockedCard: {
    opacity: 0.6,
  },
  lessonContent: {
    padding: 16,
  },
  lessonHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#E3F2FD',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  lessonInfo: {
    flex: 1,
  },
  lessonTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginBottom: 4,
  },
  lessonDescription: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  lockedText: {
    color: '#CCC',
  },
  lessonMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  difficultyChip: {
    height: 28,
  },
  rewards: {
    flexDirection: 'row',
    gap: 12,
  },
  reward: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  rewardText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#666',
  },
  progressContainer: {
    marginTop: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  progressBar: {
    flex: 1,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#E3F2FD',
  },
  progressText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#666',
    minWidth: 35,
  },
});