import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Platform, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Card, Button, ProgressBar } from 'react-native-paper';
import Animated, { FadeInUp, FadeInLeft, SlideInRight } from 'react-native-reanimated';
import { useGame } from '../../hooks/useGame';
import { mockQuizQuestions } from '../../services/mockData';

const AnimatedCard = Animated.createAnimatedComponent(Card);

export default function QuizScreen() {
  const { earnCoins } = useGame();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onOk?: () => void;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onOk?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ visible: true, title, message, onOk });
    } else {
      const Alert = require('react-native').Alert;
      Alert.alert(title, message, onOk ? [{ text: 'OK', onPress: onOk }] : undefined);
    }
  };

  const currentQuestion = mockQuizQuestions[currentQuestionIndex];
  const progress = (currentQuestionIndex + 1) / mockQuizQuestions.length;

  const handleAnswerSelect = (optionIndex: number) => {
    setSelectedAnswer(optionIndex);
  };

  const handleSubmitAnswer = () => {
    if (selectedAnswer === null) return;

    setShowResult(true);
    
    if (selectedAnswer === currentQuestion.correctAnswer) {
      setScore(prev => prev + 1);
      earnCoins(currentQuestion.coinReward);
    }

    setTimeout(() => {
      if (currentQuestionIndex < mockQuizQuestions.length - 1) {
        // Next question
        setCurrentQuestionIndex(prev => prev + 1);
        setSelectedAnswer(null);
        setShowResult(false);
      } else {
        // Quiz completed
        setQuizCompleted(true);
        const finalScore = score + (selectedAnswer === currentQuestion.correctAnswer ? 1 : 0);
        const percentage = Math.round((finalScore / mockQuizQuestions.length) * 100);
        showWebAlert(
          'Quiz Complete! 🎉',
          `Your score: ${finalScore}/${mockQuizQuestions.length} (${percentage}%)\nGreat job learning robotics!`,
          () => {
            // Reset quiz
            setCurrentQuestionIndex(0);
            setSelectedAnswer(null);
            setShowResult(false);
            setScore(0);
            setQuizCompleted(false);
          }
        );
      }
    }, 2000);
  };

  if (quizCompleted) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.completedContainer}>
          <MaterialIcons name="emoji-events" size={80} color="#FFD700" />
          <Text style={styles.completedTitle}>Quiz Complete!</Text>
          <Text style={styles.completedScore}>Score: {score}/{mockQuizQuestions.length}</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Robotics Quiz</Text>
          <Text style={styles.subtitle}>Test your knowledge and earn coins!</Text>
        </View>

        {/* Progress */}
        <AnimatedCard entering={FadeInUp.delay(100)} style={styles.progressCard}>
          <Card.Content>
            <View style={styles.progressHeader}>
              <Text style={styles.progressText}>
                Question {currentQuestionIndex + 1} of {mockQuizQuestions.length}
              </Text>
              <View style={styles.scoreContainer}>
                <MaterialIcons name="monetization-on" size={16} color="#FF9800" />
                <Text style={styles.scoreText}>+{currentQuestion.coinReward}</Text>
              </View>
            </View>
            <ProgressBar 
              progress={progress} 
              color="#00BCD4"
              style={styles.progressBar}
            />
          </Card.Content>
        </AnimatedCard>

        {/* Question */}
        <AnimatedCard entering={FadeInLeft.delay(200)} style={styles.questionCard}>
          <Card.Content>
            <View style={styles.questionHeader}>
              <MaterialIcons name="help-outline" size={24} color="#00BCD4" />
              <Text style={styles.difficultyBadge}>{currentQuestion.difficulty}</Text>
            </View>
            <Text style={styles.questionText}>{currentQuestion.question}</Text>
          </Card.Content>
        </AnimatedCard>

        {/* Options */}
        <View style={styles.optionsContainer}>
          {currentQuestion.options.map((option, index) => (
            <AnimatedCard 
              key={index}
              entering={SlideInRight.delay(300 + index * 100)}
              style={[
                styles.optionCard,
                selectedAnswer === index && styles.selectedOption,
                showResult && index === currentQuestion.correctAnswer && styles.correctOption,
                showResult && selectedAnswer === index && index !== currentQuestion.correctAnswer && styles.wrongOption
              ]}
            >
              <TouchableOpacity
                onPress={() => handleAnswerSelect(index)}
                disabled={showResult}
                style={styles.optionContent}
              >
                <View style={[
                  styles.optionBullet,
                  selectedAnswer === index && styles.selectedBullet,
                  showResult && index === currentQuestion.correctAnswer && styles.correctBullet,
                  showResult && selectedAnswer === index && index !== currentQuestion.correctAnswer && styles.wrongBullet
                ]}>
                  <Text style={[
                    styles.optionBulletText,
                    selectedAnswer === index && styles.selectedBulletText
                  ]}>
                    {String.fromCharCode(65 + index)}
                  </Text>
                </View>
                <Text style={[
                  styles.optionText,
                  selectedAnswer === index && styles.selectedOptionText,
                  showResult && index === currentQuestion.correctAnswer && styles.correctOptionText
                ]}>
                  {option}
                </Text>
                {showResult && index === currentQuestion.correctAnswer && (
                  <MaterialIcons name="check-circle" size={24} color="#4CAF50" />
                )}
                {showResult && selectedAnswer === index && index !== currentQuestion.correctAnswer && (
                  <MaterialIcons name="cancel" size={24} color="#F44336" />
                )}
              </TouchableOpacity>
            </AnimatedCard>
          ))}
        </View>

        {/* Explanation */}
        {showResult && (
          <AnimatedCard entering={FadeInUp} style={styles.explanationCard}>
            <Card.Content>
              <View style={styles.explanationHeader}>
                <MaterialIcons name="lightbulb" size={20} color="#FF9800" />
                <Text style={styles.explanationTitle}>Explanation</Text>
              </View>
              <Text style={styles.explanationText}>{currentQuestion.explanation}</Text>
            </Card.Content>
          </AnimatedCard>
        )}

        {/* Submit Button */}
        {!showResult && (
          <Button
            mode="contained"
            onPress={handleSubmitAnswer}
            disabled={selectedAnswer === null}
            style={styles.submitButton}
            buttonColor="#00BCD4"
          >
            Submit Answer
          </Button>
        )}
      </ScrollView>

      {/* Web Alert Modal */}
      {Platform.OS === 'web' && (
        <Modal visible={alertConfig.visible} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>{alertConfig.title}</Text>
              <Text style={styles.modalMessage}>{alertConfig.message}</Text>
              <TouchableOpacity 
                style={styles.modalButton}
                onPress={() => {
                  alertConfig.onOk?.();
                  setAlertConfig(prev => ({ ...prev, visible: false }));
                }}
              >
                <Text style={styles.modalButtonText}>OK</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA',
  },
  header: {
    padding: 20,
    paddingTop: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginTop: 4,
  },
  progressCard: {
    margin: 20,
    marginTop: 0,
    backgroundColor: '#FFFFFF',
    elevation: 2,
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  progressText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  scoreContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  scoreText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#FF9800',
  },
  progressBar: {
    height: 8,
    borderRadius: 4,
    backgroundColor: '#E3F2FD',
  },
  questionCard: {
    margin: 20,
    marginTop: 16,
    backgroundColor: '#FFFFFF',
    elevation: 2,
  },
  questionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  difficultyBadge: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#00BCD4',
    backgroundColor: '#E3F2FD',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  questionText: {
    fontSize: 18,
    color: '#1A1A1A',
    lineHeight: 26,
  },
  optionsContainer: {
    paddingHorizontal: 20,
  },
  optionCard: {
    marginBottom: 12,
    backgroundColor: '#FFFFFF',
    elevation: 1,
  },
  selectedOption: {
    borderColor: '#00BCD4',
    borderWidth: 2,
  },
  correctOption: {
    borderColor: '#4CAF50',
    borderWidth: 2,
    backgroundColor: '#E8F5E8',
  },
  wrongOption: {
    borderColor: '#F44336',
    borderWidth: 2,
    backgroundColor: '#FFEBEE',
  },
  optionContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  optionBullet: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  selectedBullet: {
    backgroundColor: '#00BCD4',
  },
  correctBullet: {
    backgroundColor: '#4CAF50',
  },
  wrongBullet: {
    backgroundColor: '#F44336',
  },
  optionBulletText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#666',
  },
  selectedBulletText: {
    color: '#FFFFFF',
  },
  optionText: {
    flex: 1,
    fontSize: 16,
    color: '#1A1A1A',
  },
  selectedOptionText: {
    fontWeight: 'bold',
    color: '#00BCD4',
  },
  correctOptionText: {
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  explanationCard: {
    margin: 20,
    backgroundColor: '#FFF8E1',
    elevation: 2,
  },
  explanationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  explanationTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginLeft: 8,
  },
  explanationText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  submitButton: {
    margin: 20,
    borderRadius: 8,
  },
  completedContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  completedTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginTop: 20,
  },
  completedScore: {
    fontSize: 18,
    color: '#666',
    marginTop: 8,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    minWidth: 280,
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
  },
  modalMessage: {
    fontSize: 16,
    marginBottom: 20,
    textAlign: 'center',
    lineHeight: 22,
  },
  modalButton: {
    backgroundColor: '#007AFF',
    padding: 10,
    borderRadius: 4,
    minWidth: 80,
    alignItems: 'center',
  },
  modalButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});