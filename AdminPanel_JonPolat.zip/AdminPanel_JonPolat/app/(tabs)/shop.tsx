import React, { useState, Platform } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Card, Button, Chip } from 'react-native-paper';
import Animated, { FadeIn } from 'react-native-reanimated';
import { useGame } from '../../hooks/useGame';
import { ShopItem } from '../../services/types';

const AnimatedCard = Animated.createAnimatedComponent(Card);

export default function ShopScreen() {
  const { user, shopItems, purchaseItem } = useGame();
  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onOk?: () => void;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onOk?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ visible: true, title, message, onOk });
    } else {
      const Alert = require('react-native').Alert;
      Alert.alert(title, message, onOk ? [{ text: 'OK', onPress: onOk }] : undefined);
    }
  };

  const getItemTypeColor = (type: string) => {
    switch (type) {
      case 'badge': return '#FFD700';
      case 'theme': return '#9C27B0';
      case 'discount': return '#FF5722';
      case 'content': return '#00BCD4';
      default: return '#666';
    }
  };

  const getItemTypeIcon = (type: string) => {
    switch (type) {
      case 'badge': return 'military-tech';
      case 'theme': return 'palette';
      case 'discount': return 'local-offer';
      case 'content': return 'library-books';
      default: return 'shopping-cart';
    }
  };

  const handlePurchase = (item: ShopItem) => {
    if (item.purchased) {
      showWebAlert('Already Owned', 'You already own this item!');
      return;
    }

    if (user.coins < item.price) {
      showWebAlert(
        'Not Enough Coins',
        `You need ${item.price - user.coins} more coins to purchase this item.`
      );
      return;
    }

    const success = purchaseItem(item.id);
    if (success) {
      showWebAlert(
        'Purchase Successful! 🎉',
        `You have purchased ${item.name}!`
      );
    }
  };

  const renderShopItem = ({ item, index }: { item: ShopItem; index: number }) => (
    <AnimatedCard
      entering={FadeIn.delay(index * 100)}
      style={[styles.itemCard, item.purchased && styles.purchasedCard]}
    >
      <Card.Content style={styles.itemContent}>
        <View style={styles.itemHeader}>
          <View style={[
            styles.itemIcon,
            { backgroundColor: `${getItemTypeColor(item.type)}20` }
          ]}>
            <MaterialIcons 
              name={getItemTypeIcon(item.type) as any} 
              size={24} 
              color={getItemTypeColor(item.type)} 
            />
          </View>
          <View style={styles.itemInfo}>
            <Text style={[styles.itemName, item.purchased && styles.purchasedText]}>
              {item.name}
            </Text>
            <Text style={[styles.itemDescription, item.purchased && styles.purchasedText]}>
              {item.description}
            </Text>
          </View>
          {item.purchased && (
            <MaterialIcons name="check-circle" size={24} color="#4CAF50" />
          )}
        </View>

        <View style={styles.itemFooter}>
          <Chip
            mode="outlined"
            textStyle={{ 
              color: getItemTypeColor(item.type),
              fontSize: 12,
              textTransform: 'capitalize'
            }}
            style={[
              styles.typeChip,
              { borderColor: getItemTypeColor(item.type) }
            ]}
          >
            {item.type}
          </Chip>

          <View style={styles.purchaseContainer}>
            <View style={styles.priceContainer}>
              <MaterialIcons name="monetization-on" size={16} color="#FF9800" />
              <Text style={styles.priceText}>{item.price}</Text>
            </View>
            <Button
              mode={item.purchased ? "outlined" : "contained"}
              onPress={() => handlePurchase(item)}
              disabled={item.purchased}
              style={styles.purchaseButton}
              buttonColor={item.purchased ? undefined : "#00BCD4"}
              textColor={item.purchased ? "#4CAF50" : undefined}
            >
              {item.purchased ? "Owned" : "Buy"}
            </Button>
          </View>
        </View>
      </Card.Content>
    </AnimatedCard>
  );

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>RoboShop</Text>
          <Text style={styles.subtitle}>Spend your coins on awesome rewards!</Text>
        </View>
        <View style={styles.coinsContainer}>
          <MaterialIcons name="monetization-on" size={24} color="#FF9800" />
          <Text style={styles.coinsText}>{user.coins}</Text>
        </View>
      </View>

      {/* Shop Categories */}
      <View style={styles.categoriesContainer}>
        <Text style={styles.categoriesTitle}>Available Items</Text>
        <Text style={styles.categoriesSubtitle}>
          Unlock badges, themes, and real robotics kit discounts
        </Text>
      </View>

      {/* Shop Items */}
      <FlatList
        data={shopItems}
        renderItem={renderShopItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />

      {/* Web Alert Modal */}
      {Platform.OS === 'web' && (
        <Modal visible={alertConfig.visible} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>{alertConfig.title}</Text>
              <Text style={styles.modalMessage}>{alertConfig.message}</Text>
              <TouchableOpacity 
                style={styles.modalButton}
                onPress={() => {
                  alertConfig.onOk?.();
                  setAlertConfig(prev => ({ ...prev, visible: false }));
                }}
              >
                <Text style={styles.modalButtonText}>OK</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingTop: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginTop: 4,
  },
  coinsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF8E1',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    gap: 4,
  },
  coinsText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FF9800',
  },
  categoriesContainer: {
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  categoriesTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  categoriesSubtitle: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  listContainer: {
    padding: 20,
    paddingTop: 0,
  },
  itemCard: {
    marginBottom: 16,
    backgroundColor: '#FFFFFF',
    elevation: 2,
  },
  purchasedCard: {
    opacity: 0.7,
  },
  itemContent: {
    padding: 16,
  },
  itemHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  itemIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  itemInfo: {
    flex: 1,
  },
  itemName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginBottom: 4,
  },
  itemDescription: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  purchasedText: {
    color: '#999',
  },
  itemFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  typeChip: {
    height: 28,
  },
  purchaseContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  priceText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FF9800',
  },
  purchaseButton: {
    borderRadius: 6,
    minWidth: 80,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    minWidth: 280,
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
  },
  modalMessage: {
    fontSize: 16,
    marginBottom: 20,
    textAlign: 'center',
    lineHeight: 22,
  },
  modalButton: {
    backgroundColor: '#007AFF',
    padding: 10,
    borderRadius: 4,
    minWidth: 80,
    alignItems: 'center',
  },
  modalButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});