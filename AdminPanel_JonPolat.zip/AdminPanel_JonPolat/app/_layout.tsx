import { Stack } from 'expo-router';
import { GameProvider } from '../contexts/GameContext';
import { PaperProvider } from 'react-native-paper';

export default function RootLayout() {
  return (
    <PaperProvider>
      <GameProvider>
        <Stack screenOptions={{ headerShown: false }}>
          <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        </Stack>
      </GameProvider>
    </PaperProvider>
  );
}