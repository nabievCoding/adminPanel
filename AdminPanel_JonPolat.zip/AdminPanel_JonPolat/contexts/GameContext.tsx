import React, { createContext, useState, ReactNode } from 'react';
import { User, Lesson, Achievement, ShopItem, LeaderboardEntry } from '../services/types';
import { mockUser, mockLessons, mockAchievements, mockShopItems, mockLeaderboard } from '../services/mockData';

interface GameContextType {
  user: User;
  lessons: Lesson[];
  achievements: Achievement[];
  shopItems: ShopItem[];
  leaderboard: LeaderboardEntry[];
  completeLesson: (lessonId: string) => void;
  earnCoins: (amount: number) => void;
  purchaseItem: (itemId: string) => boolean;
  updateLessonProgress: (lessonId: string, progress: number) => void;
}

export const GameContext = createContext<GameContextType | undefined>(undefined);

export function GameProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User>(mockUser);
  const [lessons, setLessons] = useState<Lesson[]>(mockLessons);
  const [achievements, setAchievements] = useState<Achievement[]>(mockAchievements);
  const [shopItems, setShopItems] = useState<ShopItem[]>(mockShopItems);
  const [leaderboard] = useState<LeaderboardEntry[]>(mockLeaderboard);

  const completeLesson = (lessonId: string) => {
    setLessons(prev => prev.map(lesson => 
      lesson.id === lessonId 
        ? { ...lesson, completed: true, progress: 100 }
        : lesson
    ));
    
    const lesson = lessons.find(l => l.id === lessonId);
    if (lesson) {
      earnCoins(lesson.coinReward);
      setUser(prev => ({
        ...prev,
        totalXP: prev.totalXP + lesson.xpReward
      }));
    }
  };

  const earnCoins = (amount: number) => {
    setUser(prev => ({
      ...prev,
      coins: prev.coins + amount
    }));
  };

  const purchaseItem = (itemId: string): boolean => {
    const item = shopItems.find(i => i.id === itemId);
    if (!item || item.purchased || user.coins < item.price) {
      return false;
    }

    setUser(prev => ({
      ...prev,
      coins: prev.coins - item.price
    }));

    setShopItems(prev => prev.map(shopItem =>
      shopItem.id === itemId
        ? { ...shopItem, purchased: true }
        : shopItem
    ));

    return true;
  };

  const updateLessonProgress = (lessonId: string, progress: number) => {
    setLessons(prev => prev.map(lesson =>
      lesson.id === lessonId
        ? { ...lesson, progress: Math.min(100, Math.max(0, progress)) }
        : lesson
    ));
  };

  return (
    <GameContext.Provider value={{
      user,
      lessons,
      achievements,
      shopItems,
      leaderboard,
      completeLesson,
      earnCoins,
      purchaseItem,
      updateLessonProgress
    }}>
      {children}
    </GameContext.Provider>
  );
}