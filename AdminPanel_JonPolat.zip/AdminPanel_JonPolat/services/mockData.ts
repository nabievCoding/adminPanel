import { User, Lesson, Achievement, ShopItem, LeaderboardEntry, QuizQuestion } from './types';

export const mockUser: User = {
  id: '1',
  name: 'Alex Robot',
  avatar: '🤖',
  level: 7,
  coins: 485,
  streak: 12,
  totalXP: 2340
};

export const mockLessons: Lesson[] = [
  {
    id: '1',
    title: 'Introduction to Robotics',
    description: 'Learn the basics of what robots are and how they work',
    difficulty: 'Beginner',
    xpReward: 50,
    coinReward: 10,
    completed: true,
    locked: false,
    progress: 100,
    icon: 'robot',
    category: 'basics'
  },
  {
    id: '2',
    title: 'Sensors and Input',
    description: 'Understanding how robots perceive their environment',
    difficulty: 'Beginner',
    xpReward: 75,
    coinReward: 15,
    completed: true,
    locked: false,
    progress: 100,
    icon: 'sensors',
    category: 'sensors'
  },
  {
    id: '3',
    title: 'Motors and Movement',
    description: 'How robots move and control their actions',
    difficulty: 'Intermediate',
    xpReward: 100,
    coinReward: 20,
    completed: false,
    locked: false,
    progress: 65,
    icon: 'settings',
    category: 'motors'
  },
  {
    id: '4',
    title: 'Programming Basics',
    description: 'Write your first robot program',
    difficulty: 'Intermediate',
    xpReward: 125,
    coinReward: 25,
    completed: false,
    locked: false,
    progress: 0,
    icon: 'code',
    category: 'programming'
  },
  {
    id: '5',
    title: 'Advanced AI Concepts',
    description: 'Machine learning for robotics',
    difficulty: 'Advanced',
    xpReward: 200,
    coinReward: 40,
    completed: false,
    locked: true,
    progress: 0,
    icon: 'psychology',
    category: 'programming'
  }
];

export const mockAchievements: Achievement[] = [
  {
    id: '1',
    title: 'First Steps',
    description: 'Complete your first lesson',
    icon: 'emoji-events',
    unlocked: true,
    progress: 1,
    target: 1,
    coinReward: 50
  },
  {
    id: '2',
    title: 'Streak Master',
    description: 'Maintain a 7-day learning streak',
    icon: 'local-fire-department',
    unlocked: true,
    progress: 7,
    target: 7,
    coinReward: 100
  },
  {
    id: '3',
    title: 'Quiz Champion',
    description: 'Score 100% on 10 quizzes',
    icon: 'quiz',
    unlocked: false,
    progress: 6,
    target: 10,
    coinReward: 150
  }
];

export const mockShopItems: ShopItem[] = [
  {
    id: '1',
    name: 'Golden Gear Badge',
    description: 'Show off your engineering skills',
    price: 100,
    type: 'badge',
    icon: 'engineering',
    purchased: false
  },
  {
    id: '2',
    name: 'Robot Theme',
    description: 'Futuristic blue interface theme',
    price: 200,
    type: 'theme',
    icon: 'palette',
    purchased: false
  },
  {
    id: '3',
    name: '20% Kit Discount',
    description: 'Save on real robotics kits',
    price: 300,
    type: 'discount',
    icon: 'local-offer',
    purchased: false
  }
];

export const mockLeaderboard: LeaderboardEntry[] = [
  { id: '1', name: 'RoboMaster', avatar: '🏆', points: 3500, rank: 1, streak: 25 },
  { id: '2', name: 'TechNinja', avatar: '🥷', points: 3200, rank: 2, streak: 18 },
  { id: '3', name: 'CodeBot', avatar: '🤖', points: 2950, rank: 3, streak: 22 },
  { id: '4', name: 'Alex Robot', avatar: '🤖', points: 2340, rank: 4, streak: 12 },
  { id: '5', name: 'CircuitKid', avatar: '⚡', points: 2100, rank: 5, streak: 8 }
];

export const mockQuizQuestions: QuizQuestion[] = [
  {
    id: '1',
    question: 'What is the main purpose of a sensor in robotics?',
    options: [
      'To make the robot move',
      'To gather information about the environment',
      'To store data',
      'To display information'
    ],
    correctAnswer: 1,
    explanation: 'Sensors allow robots to perceive and understand their environment by collecting data.',
    difficulty: 'easy',
    xpReward: 25,
    coinReward: 5
  },
  {
    id: '2',
    question: 'Which programming concept is essential for robot decision-making?',
    options: [
      'Variables',
      'Loops',
      'Conditional statements (if/else)',
      'Functions'
    ],
    correctAnswer: 2,
    explanation: 'Conditional statements allow robots to make decisions based on sensor input and current conditions.',
    difficulty: 'medium',
    xpReward: 50,
    coinReward: 10
  }
];