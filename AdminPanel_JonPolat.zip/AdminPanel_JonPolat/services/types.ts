export interface User {
  id: string;
  name: string;
  avatar: string;
  level: number;
  coins: number;
  streak: number;
  totalXP: number;
}

export interface Lesson {
  id: string;
  title: string;
  description: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  xpReward: number;
  coinReward: number;
  completed: boolean;
  locked: boolean;
  progress: number; // 0-100
  icon: string;
  category: 'basics' | 'sensors' | 'motors' | 'programming' | 'projects';
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  progress: number;
  target: number;
  coinReward: number;
}

export interface ShopItem {
  id: string;
  name: string;
  description: string;
  price: number;
  type: 'badge' | 'theme' | 'discount' | 'content';
  icon: string;
  purchased: boolean;
}

export interface LeaderboardEntry {
  id: string;
  name: string;
  avatar: string;
  points: number;
  rank: number;
  streak: number;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
  xpReward: number;
  coinReward: number;
}