import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useAuth } from '@/hooks/useAuth'
import { Loader2, BookOpen, Users, BarChart3 } from 'lucide-react'

export default function AuthPage() {
  const [isLoading, setIsLoading] = useState(false)
  const { signIn, signUp } = useAuth()

  const handleSignIn = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsLoading(true)

    const formData = new FormData(e.currentTarget)
    const email = formData.get('email')
    const password = formData.get('password')

    await signIn(email, password)
    setIsLoading(false)
  }

  const handleSignUp = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsLoading(true)

    const formData = new FormData(e.currentTarget)
    const email = formData.get('email')
    const password = formData.get('password')
    const username = formData.get('username')

    await signUp(email, password, username)
    setIsLoading(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl grid lg:grid-cols-2 gap-8 items-center">
        {/* Left Side - Branding */}
        <div className="space-y-8 text-center lg:text-left">
          <div className="space-y-4">
            <div className="flex items-center gap-3 justify-center lg:justify-start">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-xl">EP</span>
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">EduPlatform</h1>
                <p className="text-gray-600">Admin Dashboard</p>
              </div>
            </div>
            
            <div className="space-y-2">
              <h2 className="text-4xl font-bold text-gray-900 leading-tight">
                Ta'lim Platformasini
                <br />
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Professional Boshqaring
                </span>
              </h2>
              <p className="text-lg text-gray-600 max-w-md mx-auto lg:mx-0">
                Robotexnika, AI va dasturlash kurslarini yarating, do'kon va coin tizimini nazorat qiling.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-md mx-auto lg:max-w-none">
            <div className="text-center p-4 bg-white/50 rounded-xl backdrop-blur-sm">
              <BookOpen className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <p className="font-semibold text-gray-900">Kurslar</p>
              <p className="text-sm text-gray-600">To'liq boshqaruv</p>
            </div>
            <div className="text-center p-4 bg-white/50 rounded-xl backdrop-blur-sm">
              <Users className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <p className="font-semibold text-gray-900">Talabalar</p>
              <p className="text-sm text-gray-600">Faoliyat nazorati</p>
            </div>
            <div className="text-center p-4 bg-white/50 rounded-xl backdrop-blur-sm">
              <BarChart3 className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <p className="font-semibold text-gray-900">Analitika</p>
              <p className="text-sm text-gray-600">Real vaqt statistika</p>
            </div>
          </div>
        </div>

        {/* Right Side - Auth Form */}
        <div className="w-full max-w-md mx-auto">
          <Card className="border-0 shadow-xl">
            <CardHeader className="text-center pb-4">
              <CardTitle className="text-2xl">Admin Panelga Kirish</CardTitle>
              <CardDescription>
                Hisobingizga kiring yoki yangi hisob yarating
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="signin" className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-6">
                  <TabsTrigger value="signin">Kirish</TabsTrigger>
                  <TabsTrigger value="signup">Ro'yxat</TabsTrigger>
                </TabsList>

                <TabsContent value="signin">
                  <form onSubmit={handleSignIn} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="signin-email">Email</Label>
                      <Input
                        id="signin-email"
                        name="email"
                        type="email"
                        placeholder="admin@example.com"
                        required
                        disabled={isLoading}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="signin-password">Parol</Label>
                      <Input
                        id="signin-password"
                        name="password"
                        type="password"
                        placeholder="••••••••"
                        required
                        disabled={isLoading}
                      />
                    </div>
                    <Button type="submit" className="w-full" disabled={isLoading}>
                      {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      Kirish
                    </Button>
                  </form>
                </TabsContent>

                <TabsContent value="signup">
                  <form onSubmit={handleSignUp} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="signup-username">Ism</Label>
                      <Input
                        id="signup-username"
                        name="username"
                        placeholder="Admin Ismi"
                        required
                        disabled={isLoading}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="signup-email">Email</Label>
                      <Input
                        id="signup-email"
                        name="email"
                        type="email"
                        placeholder="admin@example.com"
                        required
                        disabled={isLoading}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="signup-password">Parol</Label>
                      <Input
                        id="signup-password"
                        name="password"
                        type="password"
                        placeholder="••••••••"
                        required
                        disabled={isLoading}
                      />
                    </div>
                    <Button type="submit" className="w-full" disabled={isLoading}>
                      {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      Ro'yxatdan o'tish
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* Setup Instructions */}
          <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
            <h4 className="font-medium text-green-800 mb-2">✅ Haqiqiy Ma'lumotlar Bazasi</h4>
            <div className="text-sm text-green-700 space-y-2">
              <p><strong>Bu dastur endi haqiqiy Supabase ma'lumotlar bazasi bilan ishlaydi:</strong></p>
              <p>• Kurslar, mahsulotlar va foydalanuvchilar</p>
              <p>• Coin tranzaksiyalari va analitika</p>
              <p>• Real-time ma'lumotlar yangilanishi</p>
              <div className="mt-3 p-2 bg-white rounded border">
                <p className="font-medium text-green-800">Yangi hisob yarating:</p>
                <p>Istalgan email va parol bilan ro'yxatdan o'ting</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}