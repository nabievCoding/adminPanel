import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'

export function useAnalytics() {
  return useQuery({
    queryKey: ['analytics'],
    queryFn: async () => {
      try {
        // User statistics
        const { count: totalUsers } = await supabase
          .from('user_profiles')
          .select('*', { count: 'exact', head: true })

        const { count: premiumUsers } = await supabase
          .from('user_profiles')
          .select('*', { count: 'exact', head: true })
          .eq('is_premium', true)

        // Course statistics
        const { count: totalCourses } = await supabase
          .from('courses')
          .select('*', { count: 'exact', head: true })

        const { count: premiumCourses } = await supabase
          .from('courses')
          .select('*', { count: 'exact', head: true })
          .eq('is_premium', true)

        // Enrollment statistics
        const { count: totalEnrollments } = await supabase
          .from('user_courses')
          .select('*', { count: 'exact', head: true })

        const { count: completedCourses } = await supabase
          .from('user_courses')
          .select('*', { count: 'exact', head: true })
          .eq('is_completed', true)

        // Revenue statistics
        const { data: purchases } = await supabase
          .from('purchases')
          .select('price_paid, purchase_date')
          .order('purchase_date', { ascending: false })
          .limit(100)

        const totalRevenue = purchases?.reduce((sum, purchase) => sum + purchase.price_paid, 0) || 0

        // Recent activity
        const { data: recentPurchases } = await supabase
          .from('purchases')
          .select(`
            id,
            price_paid,
            purchase_date,
            user_id,
            product:products(name)
          `)
          .order('purchase_date', { ascending: false })
          .limit(10)

        // Monthly revenue data for charts
        const monthlyRevenue = await getMonthlyRevenue()
        const userGrowth = await getUserGrowthData()

        return {
          users: {
            total: totalUsers || 0,
            premium: premiumUsers || 0,
          },
          courses: {
            total: totalCourses || 0,
            premium: premiumCourses || 0,
          },
          enrollments: {
            total: totalEnrollments || 0,
            completed: completedCourses || 0,
          },
          revenue: {
            total: totalRevenue,
            recent: purchases || [],
          },
          recentActivity: recentPurchases || [],
          charts: {
            monthlyRevenue,
            userGrowth,
          }
        }
      } catch (error) {
        console.error('Error fetching analytics:', error)
        throw error
      }
    },
  })
}

async function getMonthlyRevenue() {
  try {
    const { data } = await supabase
      .from('purchases')
      .select('price_paid, purchase_date')
      .gte('purchase_date', new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString())

    const monthlyData = data?.reduce((acc, purchase) => {
      const month = new Date(purchase.purchase_date).toLocaleDateString('uz', { 
        year: 'numeric', 
        month: 'short' 
      })
      acc[month] = (acc[month] || 0) + purchase.price_paid
      return acc
    }, {} as Record<string, number>) || {}

    return Object.entries(monthlyData).map(([month, revenue]) => ({
      month,
      revenue,
    }))
  } catch (error) {
    console.error('Error getting monthly revenue:', error)
    return []
  }
}

async function getUserGrowthData() {
  try {
    const { data } = await supabase
      .from('user_profiles')
      .select('created_at')
      .gte('created_at', new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString())

    const monthlyData = data?.reduce((acc, user) => {
      const month = new Date(user.created_at).toLocaleDateString('uz', { 
        year: 'numeric', 
        month: 'short' 
      })
      acc[month] = (acc[month] || 0) + 1
      return acc
    }, {} as Record<string, number>) || {}

    return Object.entries(monthlyData).map(([month, users]) => ({
      month,
      users,
    }))
  } catch (error) {
    console.error('Error getting user growth:', error)
    return []
  }
}

export function useCoinTransactions() {
  return useQuery({
    queryKey: ['coin-transactions'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('coin_transactions')
        .select(`
          *,
          user_profile:user_profiles!inner(username, email),
          course:courses(title),
          product:products(name)
        `)
        .order('created_at', { ascending: false })
        .limit(100)

      if (error) throw error
      return data
    },
  })
}