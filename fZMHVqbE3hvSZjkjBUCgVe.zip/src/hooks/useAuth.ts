import { useState, useEffect } from 'react'
import { User } from '@supabase/supabase-js'
import { supabase } from '@/lib/supabase'
import { toast } from 'sonner'

export function useAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null)
      setLoading(false)
    })

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setUser(session?.user ?? null)
        setLoading(false)

        if (event === 'SIGNED_IN' && session?.user) {
          // Create user profile if doesn't exist
          await createUserProfile(session.user)
        }
      }
    )

    return () => subscription.unsubscribe()
  }, [])

  const createUserProfile = async (user: User) => {
    try {
      const { error } = await supabase
        .from('user_profiles')
        .insert({
          id: user.id,
          email: user.email,
          username: user.user_metadata?.full_name || user.email?.split('@')[0],
        })
      
      if (error && error.code !== '23505') { // Ignore duplicate key error
        console.error('Error creating user profile:', error)
      }
    } catch (err) {
      console.error('Error creating user profile:', err)
    }
  }

  const signIn = async (email: string, password: string) => {
    console.log('Attempting sign in:', { email, passwordLength: password.length })
    
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      console.log('Sign in response:', { data, error })

      if (error) {
        console.error('Auth error details:', error)
        
        // Handle specific error types
        if (error.message === 'Email not confirmed') {
          toast.error('Email tasdiqlanmagan. Iltimos, emailingizni tekshiring yoki yangi hisob yarating.')
        } else if (error.message === 'Invalid login credentials') {
          toast.error('Email yoki parol noto\'g\'ri')
        } else {
          toast.error('Kirish xatosi: ' + error.message)
        }
        return { success: false, error }
      }

      toast.success('Muvaffaqiyatli kirdingiz!')
      return { success: true, data }
    } catch (err) {
      console.error('Sign in exception:', err)
      toast.error('Kutilmagan xato yuz berdi')
      return { success: false, error: err }
    }
  }

  const signUp = async (email: string, password: string, username?: string) => {
    console.log('Attempting sign up:', { email, username, passwordLength: password.length })
    
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: username,
          },
        },
      })

      console.log('Sign up response:', { data, error })

      if (error) {
        console.error('Auth error details:', error)
        toast.error('Ro\'yxatdan o\'tish xatosi: ' + error.message)
        return { success: false, error }
      }

      toast.success('Ro\'yxatdan muvaffaqiyatli o\'tdingiz! Email tasdiqlang.')
      return { success: true, data }
    } catch (err) {
      console.error('Sign up exception:', err)
      toast.error('Kutilmagan xato yuz berdi')
      return { success: false, error: err }
    }
  }

  const signOut = async () => {
    const { error } = await supabase.auth.signOut()
    
    if (error) {
      toast.error('Chiqish xatosi: ' + error.message)
    } else {
      toast.success('Tizimdan chiqdingiz')
    }
  }

  return {
    user,
    loading,
    signIn,
    signUp,
    signOut,
  }
}