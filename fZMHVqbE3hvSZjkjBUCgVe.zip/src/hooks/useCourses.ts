import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { supabase, Course } from '@/lib/supabase'
import { toast } from 'sonner'

export function useCourses() {
  const queryClient = useQueryClient()

  const { data: courses = [], isLoading, error } = useQuery({
    queryKey: ['courses'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('courses')
        .select('*')
        .order('created_at', { ascending: false })

      if (error) {
        console.error('Error fetching courses:', error)
        throw error
      }

      return data as Course[]
    },
  })

  const createCourseMutation = useMutation({
    mutationFn: async (newCourse: Omit<Course, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await supabase
        .from('courses')
        .insert(newCourse)
        .select()
        .single()

      if (error) throw error
      return data as Course[]
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['courses'] })
      toast.success('Kurs muvaffaqiyatli yaratildi')
    },
    onError: (error) => {
      console.error('Error creating course:', error)
      toast.error('Kurs yaratishda xatolik yuz berdi')
    },
  })

  const updateCourseMutation = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<Course> & { id: string }) => {
      const { data, error } = await supabase
        .from('courses')
        .update(updates)
        .eq('id', id)
        .select()
        .single()

      if (error) throw error
      return data as Course[]
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['courses'] })
      toast.success('Kurs muvaffaqiyatli yangilandi')
    },
    onError: (error) => {
      console.error('Error updating course:', error)
      toast.error('Kurs yangilashda xatolik yuz berdi')
    },
  })

  const deleteCourseMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('courses')
        .delete()
        .eq('id', id)

      if (error) throw error
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['courses'] })
      toast.success('Kurs muvaffaqiyatli o\'chirildi')
    },
    onError: (error) => {
      console.error('Error deleting course:', error)
      toast.error('Kurs o\'chirishda xatolik yuz berdi')
    },
  })

  return {
    courses,
    isLoading,
    error,
    createCourse: createCourseMutation.mutateAsync,
    updateCourse: updateCourseMutation.mutateAsync,
    deleteCourse: deleteCourseMutation.mutateAsync,
    isCreating: createCourseMutation.isPending,
    isUpdating: updateCourseMutation.isPending,
    isDeleting: deleteCourseMutation.isPending,
  }
}

// Get course statistics
export function useCourseStats() {
  return useQuery({
    queryKey: ['course-stats'],
    queryFn: async () => {
      // Get total courses count
      const { count: totalCourses } = await supabase
        .from('courses')
        .select('*', { count: 'exact', head: true })

      // Get courses by category
      const { data: coursesByCategory } = await supabase
        .from('courses')
        .select('category')

      // Get user enrollments
      const { count: totalEnrollments } = await supabase
        .from('user_courses')
        .select('*', { count: 'exact', head: true })

      // Group courses by category
      const categoryStats = coursesByCategory?.reduce((acc, course) => {
        acc[course.category] = (acc[course.category] || 0) + 1
        return acc
      }, {} as Record<string, number>) || {}

      return {
        totalCourses: totalCourses || 0,
        totalEnrollments: totalEnrollments || 0,
        categoryStats,
      }
    },
  })
}