import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { supabase, Product } from '@/lib/supabase'
import { toast } from 'sonner'

export function useProducts() {
  const queryClient = useQueryClient()

  const { data: products = [], isLoading, error } = useQuery({
    queryKey: ['products'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('created_at', { ascending: false })

      if (error) {
        console.error('Error fetching products:', error)
        throw error
      }

      return data as Product[]
    },
  })

  const createProductMutation = useMutation({
    mutationFn: async (newProduct: Omit<Product, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await supabase
        .from('products')
        .insert(newProduct)
        .select()
        .single()

      if (error) throw error
      return data as Product[]
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['products'] })
      toast.success('Mahsulot muvaffaqiyatli yaratildi')
    },
    onError: (error) => {
      console.error('Error creating product:', error)
      toast.error('Mahsulot yaratishda xatolik yuz berdi')
    },
  })

  const updateProductMutation = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<Product> & { id: string }) => {
      const { data, error } = await supabase
        .from('products')
        .update(updates)
        .eq('id', id)
        .select()
        .single()

      if (error) throw error
      return data as Product[]
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['products'] })
      toast.success('Mahsulot muvaffaqiyatli yangilandi')
    },
    onError: (error) => {
      console.error('Error updating product:', error)
      toast.error('Mahsulot yangilashda xatolik yuz berdi')
    },
  })

  const deleteProductMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', id)

      if (error) throw error
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['products'] })
      toast.success('Mahsulot muvaffaqiyatli o\'chirildi')
    },
    onError: (error) => {
      console.error('Error deleting product:', error)
      toast.error('Mahsulot o\'chirishda xatolik yuz berdi')
    },
  })

  return {
    products,
    isLoading,
    error,
    createProduct: createProductMutation.mutateAsync,
    updateProduct: updateProductMutation.mutateAsync,
    deleteProduct: deleteProductMutation.mutateAsync,
    isCreating: createProductMutation.isPending,
    isUpdating: updateProductMutation.isPending,
    isDeleting: deleteProductMutation.isPending,
  }
}

// Get shop statistics
export function useShopStats() {
  return useQuery({
    queryKey: ['shop-stats'],
    queryFn: async () => {
      // Total products
      const { count: totalProducts } = await supabase
        .from('products')
        .select('*', { count: 'exact', head: true })

      // Active products
      const { count: activeProducts } = await supabase
        .from('products')
        .select('*', { count: 'exact', head: true })
        .eq('is_active', true)

      // Total sales
      const { count: totalSales } = await supabase
        .from('purchases')
        .select('*', { count: 'exact', head: true })

      // Revenue (total coins spent)
      const { data: revenueData } = await supabase
        .from('purchases')
        .select('price_paid')

      const totalRevenue = revenueData?.reduce((sum, purchase) => sum + purchase.price_paid, 0) || 0

      // Products by category
      const { data: productsByCategory } = await supabase
        .from('products')
        .select('category')

      const categoryStats = productsByCategory?.reduce((acc, product) => {
        acc[product.category] = (acc[product.category] || 0) + 1
        return acc
      }, {} as Record<string, number>) || {}

      return {
        totalProducts: totalProducts || 0,
        activeProducts: activeProducts || 0,
        totalSales: totalSales || 0,
        totalRevenue,
        categoryStats,
      }
    },
  })
}