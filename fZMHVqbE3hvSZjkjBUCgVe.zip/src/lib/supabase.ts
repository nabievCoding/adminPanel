import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Supabase environment variables missing!')
  console.error({
    url: supabaseUrl ? 'Found' : 'Missing',
    key: supabaseAnonKey ? 'Found' : 'Missing'
  })
}

console.log('Supabase config loaded:', {
  url: supabaseUrl,
  keyExists: !!supabaseAnonKey
})

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true
  }
})

// Database types
export interface Course {
  id: string
  title: string
  description: string
  category: 'ai' | 'robotics' | 'programming' | 'web'
  difficulty: 'Boshlang\'ich' | 'O\'rta' | 'Yuqori'
  xp_reward: number
  coin_reward: number
  total_lessons: number
  duration: string
  is_premium: boolean
  is_locked: boolean
  image_url?: string
  created_by?: string
  created_at: string
  updated_at: string
}

export interface Product {
  id: string
  name: string
  description: string
  price: number
  category: 'gadgets' | 'books' | 'software' | 'hardware' | 'accessories'
  rarity: 'common' | 'rare' | 'epic' | 'legendary'
  level_required: number
  is_premium: boolean
  has_discount: boolean
  discount_percent: number
  image_url?: string
  stock_quantity: number
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface UserProfile {
  id: string
  username?: string
  email: string
  level: number
  xp: number
  coins: number
  avatar_url?: string
  is_premium: boolean
  created_at: string
  updated_at: string
}

export interface CoinTransaction {
  id: string
  user_id: string
  transaction_type: 'reward' | 'purchase' | 'bonus' | 'penalty'
  amount: number
  description: string
  related_course_id?: string
  related_product_id?: string
  created_at: string
}

export interface Purchase {
  id: string
  user_id: string
  product_id: string
  price_paid: number
  discount_applied: number
  purchase_date: string
}

// Coin management functions
export const addCoins = async (userId: string, amount: number, description: string, transactionType = 'reward') => {
  try {
    // Start transaction
    const { data: profile, error: profileError } = await supabase
      .from('user_profiles')
      .select('coins')
      .eq('id', userId)
      .single()

    if (profileError) throw profileError

    // Update user coins
    const { error: updateError } = await supabase
      .from('user_profiles')
      .update({ coins: (profile.coins || 0) + amount })
      .eq('id', userId)

    if (updateError) throw updateError

    // Create transaction record
    const { error: transactionError } = await supabase
      .from('coin_transactions')
      .insert({
        user_id: userId,
        transaction_type: transactionType,
        amount: amount,
        description: description
      })

    if (transactionError) throw transactionError

    return { success: true }
  } catch (error) {
    console.error('Error adding coins:', error)
    return { success: false, error }
  }
}

export const deductCoins = async (userId: string, amount: number, description: string, relatedProductId?: string) => {
  try {
    // Start transaction
    const { data: profile, error: profileError } = await supabase
      .from('user_profiles')
      .select('coins')
      .eq('id', userId)
      .single()

    if (profileError) throw profileError

    if ((profile.coins || 0) < amount) {
      throw new Error('Insufficient coins')
    }

    // Update user coins
    const { error: updateError } = await supabase
      .from('user_profiles')
      .update({ coins: profile.coins - amount })
      .eq('id', userId)

    if (updateError) throw updateError

    // Create transaction record
    const { error: transactionError } = await supabase
      .from('coin_transactions')
      .insert({
        user_id: userId,
        transaction_type: 'purchase',
        amount: -amount,
        description: description,
        related_product_id: relatedProductId
      })

    if (transactionError) throw transactionError

    return { success: true }
  } catch (error) {
    console.error('Error deducting coins:', error)
    return { success: false, error }
  }
}