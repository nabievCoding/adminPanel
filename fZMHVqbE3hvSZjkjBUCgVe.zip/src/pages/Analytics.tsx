import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  BarChart3,
  TrendingUp,
  TrendingDown,
  Users,
  ShoppingCart,
  Coins,
  Download,
  Eye,
  DollarSign,
  Calendar,
  Filter
} from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts'

export default function Analytics() {
  // Sample data for charts
  const monthlyRevenue = [
    { month: 'Yan', coins: 4500, products: 23 },
    { month: 'Fev', coins: 5200, products: 31 },
    { month: 'Mar', coins: 4800, products: 28 },
    { month: 'Apr', coins: 6100, products: 42 },
    { month: 'May', coins: 5900, products: 38 },
    { month: 'Iyn', coins: 7200, products: 45 }
  ]

  const categoryData = [
    { name: 'Gadjetlar', value: 45, color: '#8b5cf6' },
    { name: 'Kitoblar', value: 25, color: '#06b6d4' },
    { name: 'Aksessuarlar', value: 20, color: '#10b981' },
    { name: 'Kurslar', value: 10, color: '#f59e0b' }
  ]

  const dailyActivity = [
    { day: 'Dush', visits: 120, sales: 8 },
    { day: 'Sesh', visits: 145, sales: 12 },
    { day: 'Chor', visits: 180, sales: 15 },
    { day: 'Pay', visits: 160, sales: 11 },
    { day: 'Juma', visits: 200, sales: 18 },
    { day: 'Shan', visits: 175, sales: 14 },
    { day: 'Yak', visits: 95, sales: 6 }
  ]

  const topProducts = [
    { name: 'Smart Robot Kit', sales: 24, revenue: 7200 },
    { name: 'Python Dasturlash Kitobi', sales: 18, revenue: 1080 },
    { name: 'Arduino Starter Kit', sales: 15, revenue: 2250 },
    { name: 'Premium Sensor Pack', sales: 12, revenue: 2400 },
    { name: 'AI Algorithms Book', sales: 9, revenue: 675 }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Analitika va Hisobotlar</h1>
          <p className="text-gray-600">Platformangiz faoliyatini kuzatib boring</p>
        </div>
        
        <div className="flex gap-3">
          <Select defaultValue="30">
            <SelectTrigger className="w-[140px]">
              <Calendar className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">So'nggi 7 kun</SelectItem>
              <SelectItem value="30">So'nggi 30 kun</SelectItem>
              <SelectItem value="90">So'nggi 3 oy</SelectItem>
              <SelectItem value="365">So'nggi yil</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Hisobotni Yuklash
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Umumiy Daromad</p>
                <p className="text-2xl font-bold text-gray-900">48,392</p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="h-4 w-4 text-green-600 mr-1" />
                  <span className="text-sm text-green-600">+15.3%</span>
                  <span className="text-sm text-gray-500 ml-1">o'tgan oyga nisbatan</span>
                </div>
              </div>
              <div className="p-3 rounded-full bg-green-100">
                <Coins className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Sotilgan Mahsulotlar</p>
                <p className="text-2xl font-bold text-gray-900">156</p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="h-4 w-4 text-green-600 mr-1" />
                  <span className="text-sm text-green-600">+8.2%</span>
                  <span className="text-sm text-gray-500 ml-1">bu oyda</span>
                </div>
              </div>
              <div className="p-3 rounded-full bg-blue-100">
                <ShoppingCart className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Faol Mijozlar</p>
                <p className="text-2xl font-bold text-gray-900">2,847</p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="h-4 w-4 text-green-600 mr-1" />
                  <span className="text-sm text-green-600">+12.1%</span>
                  <span className="text-sm text-gray-500 ml-1">yangi foydalanuvchilar</span>
                </div>
              </div>
              <div className="p-3 rounded-full bg-purple-100">
                <Users className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">O'rtacha Xarid</p>
                <p className="text-2xl font-bold text-gray-900">310</p>
                <div className="flex items-center mt-2">
                  <TrendingDown className="h-4 w-4 text-red-600 mr-1" />
                  <span className="text-sm text-red-600">-2.4%</span>
                  <span className="text-sm text-gray-500 ml-1">coin/xarid</span>
                </div>
              </div>
              <div className="p-3 rounded-full bg-orange-100">
                <DollarSign className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Trends */}
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-blue-600" />
              Oylik Daromad Tendensiyasi
            </CardTitle>
            <CardDescription>Coinlarda daromad va sotilgan mahsulotlar</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyRevenue}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="coins" fill="#3b82f6" name="Coinlar" />
                <Bar dataKey="products" fill="#8b5cf6" name="Mahsulotlar" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Category Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5 text-purple-600" />
              Kategoriya bo'yicha Taqsimot
            </CardTitle>
            <CardDescription>Sotuvlarning kategoriya bo'yicha foizi</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={120}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="grid grid-cols-2 gap-4 mt-4">
              {categoryData.map((category, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: category.color }}
                  ></div>
                  <span className="text-sm text-gray-600">{category.name}</span>
                  <span className="text-sm font-medium">{category.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Daily Activity */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-600" />
              Haftalik Faollik
            </CardTitle>
            <CardDescription>Tashrif va sotuvlar statistikasi</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={dailyActivity}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="visits" 
                  stroke="#06b6d4" 
                  strokeWidth={3}
                  name="Tashriflar"
                />
                <Line 
                  type="monotone" 
                  dataKey="sales" 
                  stroke="#10b981" 
                  strokeWidth={3}
                  name="Sotuvlar"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Top Products */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5 text-orange-600" />
              Top Mahsulotlar
            </CardTitle>
            <CardDescription>Eng ko'p sotilgan mahsulotlar</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {topProducts.map((product, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                    <span className="text-sm font-bold text-blue-600">#{index + 1}</span>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{product.name}</p>
                    <p className="text-sm text-gray-600">{product.sales} ta sotilgan</p>
                  </div>
                </div>
                <Badge variant="secondary" className="bg-green-100 text-green-700">
                  {product.revenue} coin
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Performance Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Ishlash Ko'rsatkichlari Xulosasi</CardTitle>
          <CardDescription>Asosiy ko'rsatkichlar tahlili</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-green-600 mb-2">92%</div>
              <div className="text-sm text-gray-600">Mijozlar Mamnuniyati</div>
              <div className="text-xs text-gray-500 mt-1">O'tgan oyga nisbatan +5%</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-blue-600 mb-2">78%</div>
              <div className="text-sm text-gray-600">Qaytib Kelish Darajasi</div>
              <div className="text-xs text-gray-500 mt-1">O'rtacha 73%dan yuqori</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-purple-600 mb-2">3.2x</div>
              <div className="text-sm text-gray-600">Daromad O'sish Koeffitsienti</div>
              <div className="text-xs text-gray-500 mt-1">Yillik maqsaddan 15% yuqori</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}