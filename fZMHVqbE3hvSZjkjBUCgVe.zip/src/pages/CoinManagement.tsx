import { useState } from 'react'
import { Plus, Search, Edit, Trash2, Coins, Gift, TrendingUp, Users, Settings } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { toast } from 'sonner'

interface CoinTransaction {
  id: string
  userId: string
  userName: string
  type: 'earned' | 'spent' | 'bonus' | 'refund'
  amount: number
  description: string
  date: string
}

interface CoinReward {
  id: string
  name: string
  description: string
  amount: number
  type: 'course_completion' | 'daily_login' | 'achievement' | 'referral'
  isActive: boolean
}

export default function CoinManagement() {
  const [transactions] = useState<CoinTransaction[]>([
    {
      id: '1',
      userId: 'u1',
      userName: 'Alisher Karimov',
      type: 'earned',
      amount: 100,
      description: 'Python kursi tugallandi',
      date: '2024-01-15T10:30:00'
    },
    {
      id: '2',
      userId: 'u2',
      userName: 'Malika Saidova',
      type: 'spent',
      amount: -300,
      description: 'Smart Robot Kit xarid qilindi',
      date: '2024-01-15T09:15:00'
    },
    {
      id: '3',
      userId: 'u1',
      userName: 'Alisher Karimov',
      type: 'bonus',
      amount: 50,
      description: 'Kunlik kirish mukofoti',
      date: '2024-01-15T08:00:00'
    },
    {
      id: '4',
      userId: 'u3',
      userName: 'Bobur Toshmatov',
      type: 'earned',
      amount: 150,
      description: 'Robototexnika kursi tugallandi',
      date: '2024-01-14T16:45:00'
    }
  ])

  const [rewards, setRewards] = useState<CoinReward[]>([
    {
      id: '1',
      name: 'Kurs Tugallash',
      description: 'Har bir kursni tugallaganingizda oladigan coin',
      amount: 100,
      type: 'course_completion',
      isActive: true
    },
    {
      id: '2',
      name: 'Kunlik Kirish',
      description: 'Har kuni kirganingizda oladigan coin',
      amount: 10,
      type: 'daily_login',
      isActive: true
    },
    {
      id: '3',
      name: 'Yutuq Mukofoti',
      description: 'Maxsus yutuqlar uchun coin',
      amount: 50,
      type: 'achievement',
      isActive: true
    },
    {
      id: '4',
      name: 'Do\'st Taklifi',
      description: 'Do\'stingizni taklif qilganingizda oladigan coin',
      amount: 200,
      type: 'referral',
      isActive: true
    }
  ])

  const [isRewardDialogOpen, setIsRewardDialogOpen] = useState(false)
  const [editingReward, setEditingReward] = useState<CoinReward | null>(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedType, setSelectedType] = useState<string>('all')

  const totalCoins = 48392
  const coinsSpentToday = 850
  const coinsEarnedToday = 1200
  const activeUsers = 2847

  const transactionTypes = [
    { value: 'all', label: 'Barcha tranzaksiyalar' },
    { value: 'earned', label: 'Ishlab topilgan' },
    { value: 'spent', label: 'Sarflangan' },
    { value: 'bonus', label: 'Mukofot' },
    { value: 'refund', label: 'Qaytarilgan' }
  ]

  const rewardTypes = [
    { value: 'course_completion', label: 'Kurs Tugallash' },
    { value: 'daily_login', label: 'Kunlik Kirish' },
    { value: 'achievement', label: 'Yutuq' },
    { value: 'referral', label: 'Do\'st Taklifi' }
  ]

  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = transaction.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaction.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesType = selectedType === 'all' || transaction.type === selectedType
    return matchesSearch && matchesType
  })

  const handleSaveReward = (formData: FormData) => {
    const newReward: CoinReward = {
      id: editingReward?.id || Date.now().toString(),
      name: formData.get('name') as string,
      description: formData.get('description') as string,
      amount: parseInt(formData.get('amount') as string),
      type: formData.get('type') as CoinReward['type'],
      isActive: formData.get('isActive') === 'on'
    }

    if (editingReward) {
      setRewards(prev => prev.map(r => r.id === editingReward.id ? { ...r, ...newReward } : r))
      toast.success('Mukofot muvaffaqiyatli yangilandi')
    } else {
      setRewards(prev => [...prev, newReward])
      toast.success('Yangi mukofot muvaffaqiyatli qo\'shildi')
    }

    setIsRewardDialogOpen(false)
    setEditingReward(null)
  }

  const handleDeleteReward = (rewardId: string) => {
    setRewards(prev => prev.filter(r => r.id !== rewardId))
    toast.success('Mukofot o\'chirildi')
  }

  const toggleRewardStatus = (rewardId: string) => {
    setRewards(prev => prev.map(r => 
      r.id === rewardId ? { ...r, isActive: !r.isActive } : r
    ))
    toast.success('Mukofot holati o\'zgartirildi')
  }

  const getTransactionTypeLabel = (type: string) => {
    return transactionTypes.find(t => t.value === type)?.label || type
  }

  const getTransactionTypeColor = (type: string) => {
    const colors = {
      earned: 'bg-green-100 text-green-700',
      spent: 'bg-red-100 text-red-700',
      bonus: 'bg-blue-100 text-blue-700',
      refund: 'bg-orange-100 text-orange-700'
    }
    return colors[type as keyof typeof colors] || 'bg-gray-100 text-gray-700'
  }

  const getRewardTypeLabel = (type: string) => {
    return rewardTypes.find(t => t.value === type)?.label || type
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Coin Boshqaruvi</h1>
          <p className="text-gray-600">Coin tizimini nazorat qiling va mukofotlarni sozlang</p>
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Umumiy Coinlar</p>
                <p className="text-2xl font-bold text-gray-900">{totalCoins.toLocaleString()}</p>
                <p className="text-sm text-gray-500">Platformadagi barcha coinlar</p>
              </div>
              <div className="p-3 rounded-full bg-yellow-100">
                <Coins className="h-6 w-6 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Bugun Ishlab Topilgan</p>
                <p className="text-2xl font-bold text-green-600">+{coinsEarnedToday}</p>
                <p className="text-sm text-gray-500">Foydalanuvchilar tomonidan</p>
              </div>
              <div className="p-3 rounded-full bg-green-100">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Bugun Sarflangan</p>
                <p className="text-2xl font-bold text-red-600">-{coinsSpentToday}</p>
                <p className="text-sm text-gray-500">Do'kon xaridlari</p>
              </div>
              <div className="p-3 rounded-full bg-red-100">
                <Gift className="h-6 w-6 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Faol Foydalanuvchilar</p>
                <p className="text-2xl font-bold text-blue-600">{activeUsers.toLocaleString()}</p>
                <p className="text-sm text-gray-500">Coin bilan ishlaydiganlar</p>
              </div>
              <div className="p-3 rounded-full bg-blue-100">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="transactions" className="space-y-6">
        <TabsList>
          <TabsTrigger value="transactions">Tranzaksiyalar</TabsTrigger>
          <TabsTrigger value="rewards">Mukofotlar</TabsTrigger>
          <TabsTrigger value="settings">Sozlamalar</TabsTrigger>
        </TabsList>

        <TabsContent value="transactions" className="space-y-6">
          {/* Filters */}
          <Card>
            <CardContent className="p-4">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Foydalanuvchi yoki tavsifni qidiring..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={selectedType} onValueChange={setSelectedType}>
                  <SelectTrigger className="w-full sm:w-[250px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {transactionTypes.map(type => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Transactions List */}
          <Card>
            <CardHeader>
              <CardTitle>So'nggi Tranzaksiyalar</CardTitle>
              <CardDescription>Platformadagi barcha coin harakatlari</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredTransactions.map((transaction) => (
                  <div key={transaction.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
                        <Coins className="h-5 w-5 text-gray-600" />
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">{transaction.userName}</h4>
                        <p className="text-sm text-gray-600">{transaction.description}</p>
                        <p className="text-xs text-gray-500">
                          {new Date(transaction.date).toLocaleString('uz-UZ')}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge className={getTransactionTypeColor(transaction.type)}>
                        {getTransactionTypeLabel(transaction.type)}
                      </Badge>
                      <div className={`text-lg font-bold ${
                        transaction.amount > 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {transaction.amount > 0 ? '+' : ''}{transaction.amount} coin
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rewards" className="space-y-6">
          {/* Add Reward Button */}
          <div className="flex justify-end">
            <Dialog open={isRewardDialogOpen} onOpenChange={setIsRewardDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={() => setEditingReward(null)} className="bg-green-600 hover:bg-green-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Yangi Mukofot
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg">
                <DialogHeader>
                  <DialogTitle>
                    {editingReward ? 'Mukofotni Tahrirlash' : 'Yangi Mukofot Qo\'shish'}
                  </DialogTitle>
                </DialogHeader>
                
                <form onSubmit={(e) => {
                  e.preventDefault()
                  handleSaveReward(new FormData(e.target as HTMLFormElement))
                }} className="space-y-4">
                  <div>
                    <Label htmlFor="name">Mukofot Nomi</Label>
                    <Input
                      id="name"
                      name="name"
                      defaultValue={editingReward?.name}
                      placeholder="Masalan: Kurs Tugallash Mukofoti"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="description">Tavsif</Label>
                    <Textarea
                      id="description"
                      name="description"
                      defaultValue={editingReward?.description}
                      placeholder="Mukofot haqida qisqacha ma'lumot..."
                      rows={3}
                      required
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="amount">Coin Miqdori</Label>
                      <Input
                        id="amount"
                        name="amount"
                        type="number"
                        defaultValue={editingReward?.amount}
                        min="1"
                        required
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="type">Mukofot Turi</Label>
                      <Select name="type" defaultValue={editingReward?.type}>
                        <SelectTrigger>
                          <SelectValue placeholder="Turni tanlang" />
                        </SelectTrigger>
                        <SelectContent>
                          {rewardTypes.map(type => (
                            <SelectItem key={type.value} value={type.value}>
                              {type.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Faol Mukofot</Label>
                      <p className="text-sm text-gray-600">Foydalanuvchilar uchun ochiq</p>
                    </div>
                    <Switch name="isActive" defaultChecked={editingReward?.isActive ?? true} />
                  </div>
                  
                  <div className="flex justify-end gap-3 pt-4 border-t">
                    <Button type="button" variant="outline" onClick={() => setIsRewardDialogOpen(false)}>
                      Bekor qilish
                    </Button>
                    <Button type="submit" className="bg-green-600 hover:bg-green-700">
                      {editingReward ? 'Yangilash' : 'Qo\'shish'}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          {/* Rewards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {rewards.map((reward) => (
              <Card key={reward.id} className={`${reward.isActive ? 'border-green-200' : 'border-gray-200 opacity-60'}`}>
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{reward.name}</CardTitle>
                      <Badge variant="secondary" className="mt-2">
                        {getRewardTypeLabel(reward.type)}
                      </Badge>
                    </div>
                    <Switch
                      checked={reward.isActive}
                      onCheckedChange={() => toggleRewardStatus(reward.id)}
                    />
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <CardDescription>{reward.description}</CardDescription>
                  
                  <div className="text-center p-4 bg-yellow-50 rounded-lg border">
                    <div className="text-2xl font-bold text-yellow-600">{reward.amount}</div>
                    <div className="text-sm text-yellow-700">coin mukofoti</div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1"
                      onClick={() => {
                        setEditingReward(reward)
                        setIsRewardDialogOpen(true)
                      }}
                    >
                      <Edit className="w-4 h-4 mr-1" />
                      Tahrirlash
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-red-600 hover:text-red-700"
                      onClick={() => handleDeleteReward(reward.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          {/* Coin System Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5 text-gray-600" />
                Coin Tizim Sozlamalari
              </CardTitle>
              <CardDescription>Asosiy coin tizimi parametrlarini sozlang</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="minWithdraw">Minimal Yechish Miqdori</Label>
                  <Input
                    id="minWithdraw"
                    type="number"
                    defaultValue="100"
                    placeholder="100"
                  />
                  <p className="text-sm text-gray-600 mt-1">Coinlarni yechish uchun minimal miqdor</p>
                </div>
                
                <div>
                  <Label htmlFor="maxDaily">Kunlik Maksimal Mukofot</Label>
                  <Input
                    id="maxDaily"
                    type="number"
                    defaultValue="500"
                    placeholder="500"
                  />
                  <p className="text-sm text-gray-600 mt-1">Bir kunda olish mumkin bo'lgan maksimal coin</p>
                </div>
                
                <div>
                  <Label htmlFor="exchangeRate">Ayirboshlash Kursi</Label>
                  <Input
                    id="exchangeRate"
                    type="number"
                    step="0.01"
                    defaultValue="0.01"
                    placeholder="0.01"
                  />
                  <p className="text-sm text-gray-600 mt-1">1 coin = $ kursi</p>
                </div>
                
                <div>
                  <Label htmlFor="bonusMultiplier">Mukofot Ko'paytiruvchi</Label>
                  <Input
                    id="bonusMultiplier"
                    type="number"
                    step="0.1"
                    defaultValue="1.0"
                    placeholder="1.0"
                  />
                  <p className="text-sm text-gray-600 mt-1">Maxsus hodisalar uchun ko'paytiruvchi</p>
                </div>
              </div>
              
              <div className="pt-4 border-t">
                <Button className="bg-blue-600 hover:bg-blue-700">
                  Sozlamalarni Saqlash
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* System Status */}
          <Card>
            <CardHeader>
              <CardTitle>Tizim Holati</CardTitle>
              <CardDescription>Coin tizimining hozirgi holatini ko'ring</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                  <span className="font-medium text-green-900">Coin Tizimi</span>
                  <Badge className="bg-green-100 text-green-700">Faol</Badge>
                </div>
                
                <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                  <span className="font-medium text-blue-900">Mukofot Tizimi</span>
                  <Badge className="bg-blue-100 text-blue-700">Ishlayapti</Badge>
                </div>
                
                <div className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
                  <span className="font-medium text-yellow-900">Do'kon Integratsiyasi</span>
                  <Badge className="bg-yellow-100 text-yellow-700">Sinxronlashtirilgan</Badge>
                </div>
                
                <div className="pt-4">
                  <h4 className="font-medium text-gray-900 mb-2">Bugungi Aktivlik</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Ishlab topilgan coinlar</span>
                      <span className="font-medium">{coinsEarnedToday} coin</span>
                    </div>
                    <Progress value={75} className="h-2" />
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Sarflangan coinlar</span>
                      <span className="font-medium">{coinsSpentToday} coin</span>
                    </div>
                    <Progress value={45} className="h-2" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}