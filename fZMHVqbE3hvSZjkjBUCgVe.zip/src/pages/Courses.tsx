import { useState } from 'react'
import { Plus, Search, Filter, Edit, Trash2, Video, FileText, ClipboardCheck, Loader2, BookOpen } from 'lucide-react'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Badge } from '../components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog'
import { Label } from '../components/ui/label'
import { Textarea } from '../components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select'
import { Switch } from '../components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs'
import { Progress } from '../components/ui/progress'
import { Skeleton } from '../components/ui/skeleton'
import { useCourses } from '../hooks/useCourses'

export default function Courses() {
  const { 
    courses, 
    isLoading, 
    createCourse, 
    updateCourse, 
    deleteCourse,
    isCreating,
    isUpdating,
    isDeleting
  } = useCourses()

  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingCourse, setEditingCourse] = useState(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')

  const categoryOptions = [
    { value: 'all', label: 'Barcha kategoriyalar' },
    { value: 'ai', label: 'Sun\'iy Intellekt' },
    { value: 'robotics', label: 'Robototexnika' },
    { value: 'programming', label: 'Dasturlash' },
    { value: 'web', label: 'Web Development' }
  ]

  const difficultyOptions = [
    { value: 'Boshlang\'ich', label: 'Boshlang\'ich' },
    { value: 'O\'rta', label: 'O\'rta' },
    { value: 'Yuqori', label: 'Yuqori' }
  ]

  const filteredCourses = courses?.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         course.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === 'all' || course.category === selectedCategory
    return matchesSearch && matchesCategory
  }) || []

  const handleSaveCourse = async (formData) => {
    try {
      const courseData = {
        title: formData.get('title'),
        description: formData.get('description'),
        category: formData.get('category'),
        difficulty: formData.get('difficulty'),
        xp_reward: parseInt(formData.get('xpReward')),
        coin_reward: parseInt(formData.get('coinReward')),
        total_lessons: parseInt(formData.get('totalLessons')),
        duration: formData.get('duration'),
        is_premium: formData.get('isPremium') === 'on',
        is_locked: formData.get('locked') === 'on',
      }

      if (editingCourse) {
        await updateCourse({ id: editingCourse.id, ...courseData })
      } else {
        await createCourse(courseData)
      }

      setIsDialogOpen(false)
      setEditingCourse(null)
    } catch (error) {
      console.error('Error saving course:', error)
    }
  }

  const handleDeleteCourse = async (courseId) => {
    try {
      await deleteCourse(courseId)
    } catch (error) {
      console.error('Error deleting course:', error)
    }
  }

  const getCategoryLabel = (category) => {
    return categoryOptions.find(opt => opt.value === category)?.label || category
  }

  const getCategoryColor = (category) => {
    const colors = {
      ai: 'bg-blue-100 text-blue-700',
      robotics: 'bg-purple-100 text-purple-700',
      programming: 'bg-green-100 text-green-700',
      web: 'bg-orange-100 text-orange-700'
    }
    return colors[category] || 'bg-gray-100 text-gray-700'
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Kurslar Boshqaruvi</h1>
          <p className="text-gray-600">Ta'lim kurslarini yarating va boshqaring</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingCourse(null)} className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Yangi Kurs
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingCourse ? 'Kursni Tahrirlash' : 'Yangi Kurs Qo\'shish'}
              </DialogTitle>
            </DialogHeader>
            
            <form onSubmit={(e) => {
              e.preventDefault()
              handleSaveCourse(new FormData(e.target))
            }} className="space-y-4">
              <Tabs defaultValue="basic" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="basic">Asosiy Ma'lumotlar</TabsTrigger>
                  <TabsTrigger value="content">Kontent</TabsTrigger>
                  <TabsTrigger value="settings">Sozlamalar</TabsTrigger>
                </TabsList>
                
                <TabsContent value="basic" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2">
                      <Label htmlFor="title">Kurs Nomi</Label>
                      <Input
                        id="title"
                        name="title"
                        defaultValue={editingCourse?.title}
                        placeholder="Masalan: Python Dasturlash Kursi"
                        required
                      />
                    </div>
                    
                    <div className="col-span-2">
                      <Label htmlFor="description">Tavsif</Label>
                      <Textarea
                        id="description"
                        name="description"
                        defaultValue={editingCourse?.description}
                        placeholder="Kurs haqida batafsil ma'lumot..."
                        rows={3}
                        required
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="category">Kategoriya</Label>
                      <Select name="category" defaultValue={editingCourse?.category}>
                        <SelectTrigger>
                          <SelectValue placeholder="Kategoriyani tanlang" />
                        </SelectTrigger>
                        <SelectContent>
                          {categoryOptions.slice(1).map(option => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label htmlFor="difficulty">Qiyinchilik Darajasi</Label>
                      <Select name="difficulty" defaultValue={editingCourse?.difficulty}>
                        <SelectTrigger>
                          <SelectValue placeholder="Darajani tanlang" />
                        </SelectTrigger>
                        <SelectContent>
                          {difficultyOptions.map(option => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="content" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="totalLessons">Darslar Soni</Label>
                      <Input
                        id="totalLessons"
                        name="totalLessons"
                        type="number"
                        defaultValue={editingCourse?.total_lessons}
                        min="1"
                        required
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="duration">Davomiyligi</Label>
                      <Input
                        id="duration"
                        name="duration"
                        defaultValue={editingCourse?.duration}
                        placeholder="Masalan: 8 soat"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <h4 className="font-medium text-gray-900">Kurs Materiallar</h4>
                    <div className="grid grid-cols-1 gap-3">
                      <div className="p-3 border-2 border-dashed border-gray-300 rounded-lg">
                        <div className="flex items-center gap-3 text-gray-600">
                          <Video className="h-5 w-5" />
                          <span>Video Darslar</span>
                        </div>
                      </div>
                      <div className="p-3 border-2 border-dashed border-gray-300 rounded-lg">
                        <div className="flex items-center gap-3 text-gray-600">
                          <FileText className="h-5 w-5" />
                          <span>Uyga Vazifalar</span>
                        </div>
                      </div>
                      <div className="p-3 border-2 border-dashed border-gray-300 rounded-lg">
                        <div className="flex items-center gap-3 text-gray-600">
                          <ClipboardCheck className="h-5 w-5" />
                          <span>Testlar</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="settings" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="xpReward">XP Mukofoti</Label>
                      <Input
                        id="xpReward"
                        name="xpReward"
                        type="number"
                        defaultValue={editingCourse?.xp_reward}
                        min="0"
                        required
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="coinReward">Coin Mukofoti</Label>
                      <Input
                        id="coinReward"
                        name="coinReward"
                        type="number"
                        defaultValue={editingCourse?.coin_reward}
                        min="0"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Premium Kurs</Label>
                        <p className="text-sm text-gray-600">Faqat premium foydalanuvchilar uchun</p>
                      </div>
                      <Switch name="isPremium" defaultChecked={editingCourse?.is_premium} />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Yopiq Kurs</Label>
                        <p className="text-sm text-gray-600">Kursga kirish cheklangan</p>
                      </div>
                      <Switch name="locked" defaultChecked={editingCourse?.is_locked} />
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
              
              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Bekor qilish
                </Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700" disabled={isCreating || isUpdating}>
                  {(isCreating || isUpdating) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {editingCourse ? 'Yangilash' : 'Qo\'shish'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Kurslarni qidiring..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full sm:w-[200px]">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {categoryOptions.map(option => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Courses Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, index) => (
            <Card key={index} className="overflow-hidden">
              <Skeleton className="h-48 w-full" />
              <CardHeader className="pb-3">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </CardHeader>
              <CardContent className="space-y-4">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-2 w-full" />
                <div className="flex gap-2">
                  <Skeleton className="h-8 flex-1" />
                  <Skeleton className="h-8 w-8" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCourses.map((course) => (
            <Card key={course.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              {course.image_url && (
                <div className="h-48 bg-gray-200 relative overflow-hidden">
                  <img
                    src={course.image_url}
                    alt={course.title}
                    className="w-full h-full object-cover"
                  />
                  {course.is_premium && (
                    <Badge className="absolute top-2 right-2 bg-yellow-500 text-white">
                      Premium
                    </Badge>
                  )}
                </div>
              )}
            
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <CardTitle className="text-lg mb-1">{course.title}</CardTitle>
                  <Badge className={getCategoryColor(course.category)}>
                    {getCategoryLabel(course.category)}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <CardDescription className="line-clamp-2">
                {course.description}
              </CardDescription>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-600">Yangi kurs</span>
                  <span className="font-medium text-green-600">Faol</span>
                </div>
                <Progress value={0} className="h-2" />
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-600">Darslar</p>
                  <p className="font-medium">{course.total_lessons} ta</p>
                </div>
                <div>
                  <p className="text-gray-600">Davomiylik</p>
                  <p className="font-medium">{course.duration}</p>
                </div>
                <div>
                  <p className="text-gray-600">XP</p>
                  <p className="font-medium">{course.xp_reward} ball</p>
                </div>
                <div>
                  <p className="text-gray-600">Coin</p>
                  <p className="font-medium">{course.coin_reward} coin</p>
                </div>
              </div>
              
              <div className="flex gap-2 pt-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="flex-1"
                  onClick={() => {
                    setEditingCourse(course)
                    setIsDialogOpen(true)
                  }}
                >
                  <Edit className="w-4 h-4 mr-1" />
                  Tahrirlash
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="text-red-600 hover:text-red-700"
                  onClick={() => handleDeleteCourse(course.id)}
                  disabled={isDeleting}
                >
                  {isDeleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      )}

      {filteredCourses.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Kurslar topilmadi</h3>
            <p className="text-gray-600 mb-4">Qidiruv shartlaringizga mos kurslar yo'q.</p>
            <Button onClick={() => {
              setSearchTerm('')
              setSelectedCategory('all')
            }}>
              Filtrlarni tozalash
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}