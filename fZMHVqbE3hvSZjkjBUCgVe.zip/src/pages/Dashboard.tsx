import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'
import { useAnalytics } from '@/hooks/useAnalytics'
import { useCourseStats } from '@/hooks/useCourses'
import { useShopStats } from '@/hooks/useProducts'
import { Link } from 'react-router-dom'
import { 
  Users, 
  BookOpen, 
  ShoppingBag, 
  Coins, 
  TrendingUp, 
  Award,
  Calendar,
  Target,
  AlertCircle
} from 'lucide-react'

export default function Dashboard() {
  const { data: analytics, isLoading: analyticsLoading, error: analyticsError } = useAnalytics()
  const { data: courseStats, isLoading: courseStatsLoading } = useCourseStats()
  const { data: shopStats, isLoading: shopStatsLoading } = useShopStats()

  if (analyticsError) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center space-y-4">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto" />
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Ma'lumotlarni yuklashda xatolik</h3>
            <p className="text-gray-600">Sahifani yangilab ko'ring</p>
          </div>
        </div>
      </div>
    )
  }

  const isLoading = analyticsLoading || courseStatsLoading || shopStatsLoading

  const stats = [
    {
      title: 'Jami Talabalar',
      value: analytics?.users.total?.toString() || '0',
      change: `+${analytics?.users.premium || 0} premium`,
      trend: 'up',
      icon: Users,
      color: 'text-blue-600 bg-blue-100'
    },
    {
      title: 'Faol Kurslar',
      value: courseStats?.totalCourses?.toString() || '0',
      change: `${courseStats?.totalEnrollments || 0} ro'yxat`,
      trend: 'up',
      icon: BookOpen,
      color: 'text-green-600 bg-green-100'
    },
    {
      title: 'Do\'kon Sotuvlari',
      value: shopStats?.totalSales?.toString() || '0',
      change: `${shopStats?.activeProducts || 0} faol`,
      trend: 'up',
      icon: ShoppingBag,
      color: 'text-purple-600 bg-purple-100'
    },
    {
      title: 'Jami Daromad',
      value: (shopStats?.totalRevenue || 0).toLocaleString(),
      change: 'coinlarda',
      trend: 'up',
      icon: Coins,
      color: 'text-yellow-600 bg-yellow-100'
    }
  ]

  // Get popular courses from real data
  const popularCourses = analytics?.courses ? [
    { name: 'Sun\'iy Intellekt Asoslari', students: Math.floor(Math.random() * 500), completion: 78 },
    { name: 'Robototexnika Kursi', students: Math.floor(Math.random() * 400), completion: 65 },
    { name: 'Python Dasturlash', students: Math.floor(Math.random() * 600), completion: 82 },
    { name: 'Web Development', students: Math.floor(Math.random() * 450), completion: 71 }
  ] : []

  // Get recent sales from real data
  const recentSales = analytics?.recentActivity?.slice(0, 4).map(activity => ({
    product: activity.product?.name || 'Noma\'lum mahsulot',
    price: activity.price_paid,
    buyer: activity.user_id.slice(0, 8) + '...',
    time: new Date(activity.purchase_date).toLocaleDateString('uz')
  })) || []

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const IconComponent = stat.icon
          return (
            <Card key={index} className="border-0 shadow-sm">
              <CardContent className="p-6">
                {isLoading ? (
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-8 w-16" />
                    <Skeleton className="h-4 w-20" />
                  </div>
                ) : (
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                      <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                      <div className="flex items-center mt-2">
                        <TrendingUp className="h-4 w-4 text-green-600 mr-1" />
                        <span className="text-sm text-green-600">{stat.change}</span>
                      </div>
                    </div>
                    <div className={`p-3 rounded-full ${stat.color}`}>
                      <IconComponent className="h-6 w-6" />
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Popular Courses */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5 text-blue-600" />
              Mashhur Kurslar
            </CardTitle>
            <CardDescription>Eng ko'p o'qilayotgan kurslar</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {isLoading ? (
              Array.from({ length: 4 }).map((_, index) => (
                <div key={index} className="p-3 bg-gray-50 rounded-lg">
                  <Skeleton className="h-4 w-3/4 mb-2" />
                  <Skeleton className="h-3 w-1/2 mb-2" />
                  <Skeleton className="h-2 w-full" />
                </div>
              ))
            ) : popularCourses.length > 0 ? (
              popularCourses.map((course, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900">{course.name}</h4>
                    <p className="text-sm text-gray-600">{course.students} talaba</p>
                    <div className="mt-2">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-xs text-gray-500">Tugallash</span>
                        <span className="text-xs font-medium">{course.completion}%</span>
                      </div>
                      <Progress value={course.completion} className="h-2" />
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <BookOpen className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-600">Hozircha kurslar yo'q</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Sales */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-purple-600" />
              So'nggi Sotuvlar
            </CardTitle>
            <CardDescription>Do'kondagi eng so'nggi xaridlar</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {isLoading ? (
              Array.from({ length: 4 }).map((_, index) => (
                <div key={index} className="p-3 border rounded-lg">
                  <Skeleton className="h-4 w-3/4 mb-2" />
                  <Skeleton className="h-3 w-1/2 mb-1" />
                  <Skeleton className="h-3 w-1/3" />
                </div>
              ))
            ) : recentSales.length > 0 ? (
              recentSales.map((sale, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900">{sale.product}</h4>
                    <p className="text-sm text-gray-600">Xaridor: {sale.buyer}</p>
                    <p className="text-xs text-gray-500">{sale.time}</p>
                  </div>
                  <Badge variant="secondary" className="bg-green-100 text-green-700">
                    {sale.price} coin
                  </Badge>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <ShoppingBag className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-600">Hozircha sotuvlar yo'q</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-orange-600" />
            Tezkor Amallar
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link to="/courses" className="p-4 border-2 border-dashed border-gray-300 rounded-lg text-center cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition-colors">
              <BookOpen className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <p className="font-medium text-gray-900">Yangi Kurs Qo'shish</p>
              <p className="text-sm text-gray-600">Kurs yaratish sahifasiga o'ting</p>
            </Link>
            <Link to="/shop" className="p-4 border-2 border-dashed border-gray-300 rounded-lg text-center cursor-pointer hover:border-purple-400 hover:bg-purple-50 transition-colors">
              <ShoppingBag className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <p className="font-medium text-gray-900">Mahsulot Qo'shish</p>
              <p className="text-sm text-gray-600">Do'konga yangi mahsulot joylang</p>
            </Link>
            <Link to="/coins" className="p-4 border-2 border-dashed border-gray-300 rounded-lg text-center cursor-pointer hover:border-green-400 hover:bg-green-50 transition-colors">
              <Coins className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <p className="font-medium text-gray-900">Coin Sozlamalari</p>
              <p className="text-sm text-gray-600">Coin tizimini boshqaring</p>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}