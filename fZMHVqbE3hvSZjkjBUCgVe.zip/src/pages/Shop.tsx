
import { useState } from 'react'
import { Plus, Search, Filter, Edit, Trash2, Star, Crown, Package, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Skeleton } from '@/components/ui/skeleton'
import { useProducts } from '@/hooks/useProducts'
import { Product } from '@/lib/supabase'

export default function Shop() {
  const { 
    products, 
    isLoading, 
    createProduct, 
    updateProduct, 
    deleteProduct,
    isCreating,
    isUpdating,
    isDeleting
  } = useProducts()

  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [selectedRarity, setSelectedRarity] = useState<string>('all')

  const categoryOptions = [
    { value: 'all', label: 'Barcha kategoriyalar' },
    { value: 'gadgets', label: 'Gadjetlar' },
    { value: 'books', label: 'Kitoblar' },
    { value: 'software', label: 'Dasturlar' },
    { value: 'hardware', label: 'Jihoz' },
    { value: 'accessories', label: 'Aksessuarlar' }
  ]

  const rarityOptions = [
    { value: 'all', label: 'Barcha darajalar' },
    { value: 'common', label: 'Oddiy' },
    { value: 'rare', label: 'Noyob' },
    { value: 'epic', label: 'Epik' },
    { value: 'legendary', label: 'Afsonaviy' }
  ]

  const filteredProducts = products?.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory
    const matchesRarity = selectedRarity === 'all' || product.rarity === selectedRarity
    return matchesSearch && matchesCategory && matchesRarity
  }) || []

  const handleSaveProduct = async (formData: FormData) => {
    try {
      const price = parseInt(formData.get('price') as string)
      const discountPercent = parseInt(formData.get('discountPercent') as string) || 0
      
      const productData = {
        name: formData.get('name') as string,
        description: formData.get('description') as string,
        category: formData.get('category') as Product['category'],
        rarity: formData.get('rarity') as Product['rarity'],
        price: price,
        level_required: parseInt(formData.get('levelRequired') as string),
        is_premium: formData.get('isPremium') === 'on',
        has_discount: formData.get('hasDiscount') === 'on',
        discount_percent: discountPercent,
        image_url: formData.get('image') as string || undefined,
        stock_quantity: parseInt(formData.get('stockQuantity') as string) || 100,
        is_active: true
      }

      if (editingProduct) {
        await updateProduct({ id: editingProduct.id, ...productData })
      } else {
        await createProduct(productData)
      }

      setIsDialogOpen(false)
      setEditingProduct(null)
    } catch (error) {
      console.error('Error saving product:', error)
    }
  }

  const handleDeleteProduct = async (productId: string) => {
    try {
      await deleteProduct(productId)
    } catch (error) {
      console.error('Error deleting product:', error)
    }
  }

  const getCategoryLabel = (category: string) => {
    return categoryOptions.find(opt => opt.value === category)?.label || category
  }

  const getRarityLabel = (rarity: string) => {
    return rarityOptions.find(opt => opt.value === rarity)?.label || rarity
  }

  const getRarityColor = (rarity: string) => {
    const colors = {
      common: 'bg-gray-100 text-gray-700 border-gray-300',
      rare: 'bg-blue-100 text-blue-700 border-blue-300',
      epic: 'bg-purple-100 text-purple-700 border-purple-300',
      legendary: 'bg-yellow-100 text-yellow-700 border-yellow-300'
    }
    return colors[rarity as keyof typeof colors] || colors.common
  }

  const getDiscountedPrice = (price: number, hasDiscount: boolean, discountPercent: number) => {
    if (hasDiscount && discountPercent) {
      return Math.floor(price * (1 - discountPercent / 100))
    }
    return price
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Do'kon Boshqaruvi</h1>
          <p className="text-gray-600">Mahsulotlarni yarating va narxlarni boshqaring</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingProduct(null)} className="bg-purple-600 hover:bg-purple-700">
              <Plus className="w-4 h-4 mr-2" />
              Yangi Mahsulot
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingProduct ? 'Mahsulotni Tahrirlash' : 'Yangi Mahsulot Qo\'shish'}
              </DialogTitle>
            </DialogHeader>
            
            <form onSubmit={(e) => {
              e.preventDefault()
              handleSaveProduct(new FormData(e.target as HTMLFormElement))
            }} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <Label htmlFor="name">Mahsulot Nomi</Label>
                  <Input
                    id="name"
                    name="name"
                    defaultValue={editingProduct?.name}
                    placeholder="Masalan: Smart Robot Kit"
                    required
                  />
                </div>
                
                <div className="col-span-2">
                  <Label htmlFor="description">Tavsif</Label>
                  <Textarea
                    id="description"
                    name="description"
                    defaultValue={editingProduct?.description}
                    placeholder="Mahsulot haqida batafsil ma'lumot..."
                    rows={3}
                    required
                  />
                </div>
                
                <div className="col-span-2">
                  <Label htmlFor="image">Rasm URL</Label>
                  <Input
                    id="image"
                    name="image"
                    defaultValue={editingProduct?.image_url}
                    placeholder="https://images.unsplash.com/photo-..."
                  />
                </div>
                
                <div>
                  <Label htmlFor="category">Kategoriya</Label>
                  <Select name="category" defaultValue={editingProduct?.category}>
                    <SelectTrigger>
                      <SelectValue placeholder="Kategoriyani tanlang" />
                    </SelectTrigger>
                    <SelectContent>
                      {categoryOptions.slice(1).map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="rarity">Darajasi</Label>
                  <Select name="rarity" defaultValue={editingProduct?.rarity}>
                    <SelectTrigger>
                      <SelectValue placeholder="Darajani tanlang" />
                    </SelectTrigger>
                    <SelectContent>
                      {rarityOptions.slice(1).map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="price">Narx (Coinlarda)</Label>
                  <Input
                    id="price"
                    name="price"
                    type="number"
                    defaultValue={editingProduct?.price}
                    min="1"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="levelRequired">Kerak Bo'lgan Daraja</Label>
                  <Input
                    id="levelRequired"
                    name="levelRequired"
                    type="number"
                    defaultValue={editingProduct?.level_required}
                    min="1"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="stockQuantity">Stok Miqdori</Label>
                  <Input
                    id="stockQuantity"
                    name="stockQuantity"
                    type="number"
                    defaultValue={editingProduct?.stock_quantity || 100}
                    min="0"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="discountPercent">Chegirma Foizi</Label>
                  <Input
                    id="discountPercent"
                    name="discountPercent"
                    type="number"
                    defaultValue={editingProduct?.discount_percent || 0}
                    min="0"
                    max="100"
                    placeholder="0-100 orasida"
                  />
                </div>
              </div>
              
              <div className="space-y-4 border-t pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Premium Mahsulot</Label>
                    <p className="text-sm text-gray-600">Faqat premium foydalanuvchilar uchun</p>
                  </div>
                  <Switch name="isPremium" defaultChecked={editingProduct?.is_premium} />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Chegirma Bor</Label>
                    <p className="text-sm text-gray-600">Mahsulotda chegirma mavjud</p>
                  </div>
                  <Switch name="hasDiscount" defaultChecked={editingProduct?.has_discount} />
                </div>
              </div>
              
              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Bekor qilish
                </Button>
                <Button type="submit" className="bg-purple-600 hover:bg-purple-700" disabled={isCreating || isUpdating}>
                  {(isCreating || isUpdating) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {editingProduct ? 'Yangilash' : 'Qo\'shish'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Mahsulotlarni qidiring..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-4">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full lg:w-[200px]">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categoryOptions.map(option => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={selectedRarity} onValueChange={setSelectedRarity}>
                <SelectTrigger className="w-full lg:w-[180px]">
                  <Star className="w-4 h-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {rarityOptions.map(option => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Products Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {Array.from({ length: 8 }).map((_, index) => (
            <Card key={index} className="overflow-hidden">
              <Skeleton className="h-48 w-full" />
              <CardHeader className="pb-3">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </CardHeader>
              <CardContent className="space-y-4">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <div className="flex gap-2">
                  <Skeleton className="h-8 flex-1" />
                  <Skeleton className="h-8 w-8" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => {
            const discountedPrice = getDiscountedPrice(product.price, product.has_discount, product.discount_percent)
            
            return (
              <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                {product.image_url && (
                  <div className="h-48 bg-gray-200 relative overflow-hidden">
                    <img
                      src={product.image_url}
                      alt={product.name}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://via.placeholder.com/400x300?text=No+Image'
                      }}
                    />
                    <div className="absolute top-2 left-2 flex flex-col gap-1">
                      {product.is_premium && (
                        <Badge className="bg-yellow-500 text-white">
                          <Crown className="w-3 h-3 mr-1" />
                          Premium
                        </Badge>
                      )}
                      {product.has_discount && product.discount_percent > 0 && (
                        <Badge className="bg-red-500 text-white">
                          -{product.discount_percent}%
                        </Badge>
                      )}
                    </div>
                    <Badge className={`absolute top-2 right-2 border ${getRarityColor(product.rarity)}`}>
                      {getRarityLabel(product.rarity)}
                    </Badge>
                  </div>
                )}
                
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-lg mb-1">{product.name}</CardTitle>
                      <Badge variant="secondary">
                        {getCategoryLabel(product.category)}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <CardDescription className="line-clamp-2">
                    {product.description}
                  </CardDescription>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Narx</span>
                      <div className="flex items-center gap-2">
                        {product.has_discount && product.discount_percent > 0 && (
                          <span className="text-sm text-gray-400 line-through">
                            {product.price} coin
                          </span>
                        )}
                        <span className="font-bold text-green-600">
                          {discountedPrice} coin
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Kerak Daraja</span>
                      <Badge variant="outline">
                        {product.level_required} daraja
                      </Badge>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Stok</span>
                      <Badge variant="outline" className={product.stock_quantity > 0 ? 'text-green-600' : 'text-red-600'}>
                        {product.stock_quantity} dona
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 pt-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1"
                      onClick={() => {
                        setEditingProduct(product)
                        setIsDialogOpen(true)
                      }}
                    >
                      <Edit className="w-4 h-4 mr-1" />
                      Tahrirlash
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-red-600 hover:text-red-700"
                      onClick={() => handleDeleteProduct(product.id)}
                      disabled={isDeleting}
                    >
                      {isDeleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}

      {!isLoading && filteredProducts.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Mahsulotlar topilmadi</h3>
            <p className="text-gray-600 mb-4">Qidiruv shartlaringizga mos mahsulotlar yo'q yoki hali mahsulotlar qo'shilmagan.</p>
            <Button onClick={() => {
              setSearchTerm('')
              setSelectedCategory('all')
              setSelectedRarity('all')
            }}>
              Filtrlarni tozalash
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
